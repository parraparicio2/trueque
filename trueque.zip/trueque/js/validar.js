//funcion para validar un campo tipo texto
function validarCampo(idCampo)
{
  
  campo = document.getElementById(idCampo);
  if (campo.value.length == 0)
    {
	  alert('Debe ingresar ' + campo.lang); 
	  
	  //campo.setAttribute("class","error");}
	  //fieldObj.setAttribute("className","mainFormError");
	  campo.focus();
	  return false;
	}  
}			  
/************************************************************************************/
//comprueba si un a�o es bisiesto
function comprobarSiBisisesto(anio){
if ( ( anio % 100 != 0) && ((anio % 4 == 0) || (anio % 400 == 0))) {
    return true;
    }
else {
    return false;
    }
}
/************************************************************************************/
// valida la fecha con formato dd/mm/yyyy
function validarFecha(idCampo)
{
  fecha = document.getElementById(idCampo);
  if (fecha != undefined && fecha.value != "" )
    {
      if (!/^\d{2}\/\d{2}\/\d{4}$/.test(fecha.value))
	    {
          alert("formato de fecha no v�lido (dd/mm/aaaa)");
          return false;
        }
      var dia  =  parseInt(fecha.value.substring(0,2),10);
      var mes  =  parseInt(fecha.value.substring(3,5),10);
      var anio =  parseInt(fecha.value.substring(6),10);
 
      switch(mes){
          case 1:
          case 3:
          case 5:
          case 7:
          case 8:
          case 10:
          case 12: numDias=31;
                   break;
           case 4: 
		   case 6: 
		   case 9: 
		  case 11: numDias=30;
                   break;
           case 2: if (comprobarSiBisisesto(anio)){ numDias=29 }else{ numDias=28};
                     break;
          default: alert("Fecha invalida!");
                   return false;
    }
    if (dia>numDias || dia==0)
	  {
        alert("Fecha invalida!");
        return false;
      }
        return true;
    }
}
/************************************************************************************/
function validarNumero(idCampo)
{ 
  campo = document.getElementById(idCampo);
  if (isNaN(campo.value) ) 
    {
	  alert(campo.lang + 'debe ser n�merico');
	  campo.focus();
      return false;
    }
  else 
    return true;
}

/************************************************************************************/
//esta funcion solo deja ingresar numeros enteros
function soloNumeros(e)
{
var caracter 
  caracter = e.keyCode 
  status = caracter 
  if (caracter>47 && caracter <58)
    return true
  else
    return false
}
//onkeypress="return soloNumeros(event)"

function buscarIgnorarCampo(camposIgnorados, campo)
{
	var i, arregloNombres;
	    
	arregloNombres = camposIgnorados.split(",");
	for (i=0; i < arregloNombres.length; i++)
	  {
		if ( arregloNombres[i] == campo )
		   return true;   
	  }
  return false;	
}

function validarDatos(formulario, ignorarCampos)
{
  var i;	 
  buscarIgnorarCampo(ignorarCampos);	 
  for (i=0; i < formulario.elements.length; i++)
    {
		 
	   if (formulario.elements[i].value.length == 0 && formulario.elements[i].type != 'button' &&  
		    formulario.elements[i].type != 'submit' && buscarIgnorarCampo(ignorarCampos, formulario.elements[i].name) == false) 
		  {
		      alert('debe ingresar ' + formulario.elements[i].lang + '.');
              formulario.elements[i].focus();
			  return true;
		  }
    }
   //formulario.submit();	 
}








