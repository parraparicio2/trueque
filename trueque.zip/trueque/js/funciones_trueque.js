function enviarFormulario(boton, vurl, id_formulario, funcionValidar)
{

 $(boton).click(function()
					{
					//alert('sada');

					 if (!eval(funcionValidar))
					    return false;
					 $.ajax({
								type:"POST",
								url:vurl,
								dataType:"html",
								data:$(id_formulario).serialize(),
								beforeSend:function()
											  {
												  $("#respuesta").html('Actualizando...');
											  },
								success:function(response)
										  {
										  $("#respuesta").html(response);
										  }
								})
								 return false;
					 })
} 

function enviarSesion(boton, vurl, id_formulario, funcionValidar)
{
 $(boton).click(function()
					{
					 if (!eval(funcionValidar))
					    return false;
					 $.ajax({
								type:"POST",
								url:vurl,
								dataType:"html",
								data:$(id_formulario).serialize(),
								beforeSend:function()
											  {
												  $("#respuesta").html('Iniciando...');
											  },
								success:function(response)
										  {
										  $("#respuesta").html(response);
										  }
								})
								 return false;
					 })
} 

function enviarFormularioConObjeto(boton, vurl, id_formulario, funcionValidar, objeto)
{

 $(boton).click(function()
					{
					//alert('sada');

					 if (!eval(funcionValidar))
					    return false;
					 $.ajax({
								type:"POST",
								url:vurl,
								dataType:"html",
								data:$(id_formulario).serialize(),
								beforeSend:function()
											  {
												  //$(objeto).html('Actualizando...');
											  },
								success:function(response)
										  {
										  $(objeto).html(response);
										  }
								})
								 return false;
					 })
} 



function vaciarCombo(nombrecombo){
   var combo = document.getElementById(nombrecombo);
	if (combo == null)
	   return false;
		
   while(combo.options.length > 0){
      combo.options[combo.options.length-1] = null;
   }
}

function llenarCombo(nombrecombo, texto, valor){
   var combo = document.getElementById(nombrecombo);
   var idxElemento = combo.options.length; //Numero de elementos de la combo si esta vacio es 0
   //Este indice será el del nuevo elemento
   combo.options[idxElemento] = new Option();
   combo.options[idxElemento].text = texto; //Este es el texto que verás en la combo
   combo.options[idxElemento].value = valor; //Este es el valor que se enviará cuando hagas un submit del 
//cormulario que lo contiene
   }
   
function trim(s)
{
	var l=0; var r=s.length -1;
	while(l < s.length && s[l] == ' ')
	{	l++; }
	while(r > l && s[r] == ' ')
	{	r-=1;	}
	return s.substring(l, r+1);
}
	  
function ltrim(s)
{
	var l=0;
	while(l < s.length && s[l] == ' ')
	{	l++; }
	return s.substring(l, s.length);
}

function rtrim(s)
{
	var r=s.length -1;
	while(r > 0 && s[r] == ' ')
	{	r-=1;	}
	return s.substring(0, r+1);
}	  

function seleccionarCombo(nombrecombo, valor)
{

var combo = document.getElementById(nombrecombo);
var i;
   for (i = 0; i < combo.length; i++) 
	{
		if (combo.options[i].value == valor) 
			{

			 combo.options[i].selected = true;
				break;
		  }   
   }
}

function validarLogin()
{
  
  if (validarDatos(document.frmLogin,'') )
     return false;
  document.frmLogin.action = 'frmLogin.php' 
  document.frmLogin.submit();
}

function pantallaLogin(id)
{
$( id ).dialog({
			autoOpen: false,
			height: 0,
			width: 0,
			position:'top',
			modal: true
		});

}

function validarCorreo(valor) {
if (/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/.test(valor)){
return (true)
} else {
	
alert('Correo Inválido!');	
return false;
}
}

function validarLogin(valor)
{
	if(/^[a-z0-9ü][a-z0-9ü_]{3,9}$/.test(valor))
	   return true;
	else
	{
	   alert('Nombre de Usuario inválido');	
	   return false;
	}

}







