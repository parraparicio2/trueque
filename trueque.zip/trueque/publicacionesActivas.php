<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript">
   gradiente('cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario1', '8080FF', '4D51F2', 'vertical', '', '' );
	gradiente('separador_menu_usuario2', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario3', '8080FF', '4D51F2', 'horizontal', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
</script>
<title>Datos Personales</title>
</head>

<body>
<?php
require_once("includes/funciones.php");
require_once("configuracion/configurar.php");
require_once("includes/clase_publicacion.php");
   iniciarSesion();

?>  
</div>


<div id="contenedor">
	<div id="main">
        <?php //echo $_SESSION['id_usuario']; ?>
        <iframe name = "fraPagina" id = "fraPagina"  src="publicacionBuscarActivas.php?id_usuario=<?php echo $_SESSION['id_usuario'] ?>&pagina=0"  class = "marcos" frameborder="0"/>
	</div><!--main-->
</div><!--contenedor-->
</body>
</html>
