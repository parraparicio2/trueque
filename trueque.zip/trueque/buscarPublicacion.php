<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>

<title>Busqueda de Publicaciones</title>

     
</head>
        <script type="text/javascript">
            $(document).ready(function(){
                function loading_show(){
                    $('#loading').html("<img src='images/bigLoader.gif'/>").fadeIn('fast');
                }
                function loading_hide(){
                    $('#loading').fadeOut('fast');
                }                
                function loadData(page){
                    loading_show();                    
                    $.ajax
                    ({
                        type: "POST",
                        url: "publicacionBuscar.php",
                        data: "page="+page+"&txtBuscar=<?php echo $_POST['txtBuscar'] ?>&cbEstado=<?php echo $_POST['cbEstado'] ?>",
                        success: function(msg)
                        {
                            $("#container").ajaxComplete(function(event, request, settings)
                            {
                                loading_hide();
                                $("#container").html(msg);
                            });
                        }
                    });
                }
                loadData(1);  // For first time page load default results
                $('#container .pagination li.active').live('click',function(){
                    var page = $(this).attr('p');
                    loadData(page);
                    
                });           
                $('#go_btn').live('click',function(){
                    var page = parseInt($('.goto').val());
                    var no_of_pages = parseInt($('.total').attr('a'));
                    if(page != 0 && page <= no_of_pages){
                        loadData(page);
                    }else{
                        alert('Ingrese una P�gina entre 1 y '+ no_of_pages);
                        $('.goto').val("").focus();
                        return false;
                    }
                    
                });
            });
        </script>


<body>

<div id ="contenedor">
   <div id ="main">
	    <div id = "paginacion" class ="paginacion_publicacion" > 
		  <div id="loading"></div>
		      <div id ="paginacion_cuerpo" >
			     <div id ="container" class="paginacion_publicacion">
				 </div>
			   </div>
		</div>
			   
	</div>
</div>

</body>
</html>
