<?php
   
   require_once("includes/clase_usuario.php"); 
   session_start();
   echo usuario::usuarioBuscarPassword($_SESSION['id_usuario'], $_POST['txtPasswordActual']);
?>

