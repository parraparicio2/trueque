<?php
  require_once("includes/clase_usuario.php");
  require_once("includes/funciones.php");
  $mensaje = usuario::usuarioBaja($_POST['id_usuario'],
                             $_POST['txtMotivo']    
							 );
							 
  echo $mensaje;	
  //header('Location:logout.php');
  						 
  							 
    //enviarCorreo($_POST['txtCorreo'], CORREO_USUARIO, CORREO_NOMBRE, 'Bienvenido a Tus Trueques', $body);                                          
                                         

?>
<script>parent.window.location='logout.php'</script>
