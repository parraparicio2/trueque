<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript">
  // gradiente('cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Logout</title>
</head>

<body>
<?php
  session_start();
  $_SESSION = array();
  session_destroy();
  

?>

  <a href='index.php'>
	<div id='cabecera_logo'>
		<div id='logo'>
		</div> 
	</div>
  </a>
  
  <div id ='botones_cabecera' class ='botones_cabecera' >
        <div class = 'div_boton' >
           <a class='enlaceboton' href='frmPublicar.php'>Publicar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./miCuenta.php'>Mi Cuenta</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./frmRegistrarUsuarios.php'>Registrarse</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./login.php'>Ingresar</a>
        </div>
  </div><!--botones_cabecera-->

<div id ="contenedor">
  <div id ="main" style="margin-top:200px">
     <div style="margin: 0 auto; width:700px; text-align:center">
        <form id="frmLogout" name = "frmLogout" method = "post" action ="index.php" class="formulario" style="padding:30px">
        <p>La sesi&oacute;n a finalizado</p>
        <input type="submit" name = "cmdAceptar" value="Aceptar" class="boton_comando">
        </form>
        </div>
  </div><!--contenedor-->
</div><!--main--> 
</body>
</html>