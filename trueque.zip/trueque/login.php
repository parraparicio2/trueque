<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript">
   //gradiente('botones_cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );

 	
</script>
<title>Ingreso de Usuarios</title>
</head>

<?php 
  require_once('includes/funciones.php'); 
	datosUsuario();

?>
  <a href='index.php'>
	<div id='cabecera_logo'>
		<div id='logo'>
		</div> 
	</div>
   </a> 

    <div id ='botones_cabecera' class ='botones_cabecera' >
        <div class = 'div_boton' >
           <a class='enlaceboton' href='frmPublicar.php'>Publicar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./miCuenta.php'>Mi Cuenta</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./frmRegistrarUsuarios.php'>Registrarse</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./index.php'>Inicio</a>
        </div>
  </div><!--botones_cabecera-->



<div id="contenedor_corto">
   <div id="main_corto" style="margin-top:40px;">
      <div id ="div_borde" style="border: 1px #CCC solid; height:250px; padding:10px; float:left; margin-top:20px;"> 
         <div id = "div_titulo" class = "titulo" style="padding-left:2px; text-align:justify"> Ingresar a Tu Trueque </div>
         <div style="padding:10px"> </div>
 <!--------------------------------------------------------------------------------------------------->           
         <div id ="div_login" class = "columna_izquierda" style="width:50%; height:150px; ">
            <form class = "formulario_corto" id="frmLogin" name="frmLogin" method="post" action="usuarioIngresar.php">
                  <div id="" class="fila" style="height:100%">
                     <div class="columna_izquierda_p">Login</div>
                     <div class="columna_derecha_p" style="width:150px">
                        <input name="txtLogin" class ="campo_corto" id="txtLogin"  maxlength="16" lang="el login"   />
                     </div>
                  </div><!--fila-->
                  
                  <div id="" class="fila">
                     <div class="columna_izquierda_p">Contrase&ntilde;a</div>
                     <div class="columna_derecha_p" style="width:150px">
                        <input class ="campo_corto"  type="password" name="txtPassword" id="txtPassword" maxlength="16" lang ="la contrase�a"/>
                     </div>
                  </div><!--fila--> 
               
               <div class ="botones_formulario">
                  <input class = "boton_comando" id ="cmdAceptar" name="cmdAceptar" type="submit" value="Aceptar" onclick="validarPagina()"/>
                  <input class = "boton_comando" id ="cmdCancelar" name="cmdCancelar" type="button" value="Cancelar" onclick= "history.back()" />
               </div>
            </form>
         </div><!--columna izquierda-->
 <!--------------------------------------------------------------------------------------------------->           
         <div id= "div_registrar" class = "columna_derecha" style="border-left: 2px solid #999; width:40%; height:150px;  ">
            <p style="font-size:16px; font-weight:600; text-align:center" >¿No estas registrado?</p>
            <p style="font-size:12px; text-align:justify"> Registrate para realizar intercambios con otras personas!</p>
            <div class="botones_formulario">
               <input class = "boton_comando" type="submit" name="cmdRegistrar" id="cmdRegistrar" value="Registrarse" onclick="window.location = 'frmRegistrarUsuarios.php';	 "/>
            </div><!--botones_formulario--> 
         </div><!--columna_derecha--> 
      </div>
      
   </div><!--main_corto-->
</div><!--contenedor_corto-->
<!--div id = "desarrollado" > Dise�ado por Carlos Parra</div><!--footer--> 
<script type="text/javascript">

function validarPagina()
{
  
  if (validarDatos(document.frmLogin,'') )
     return false;
  document.frmLogin.action = 'usuarioIngresar.php' 
  document.frmLogin.submit();
}

</script>
</body>
</html>
