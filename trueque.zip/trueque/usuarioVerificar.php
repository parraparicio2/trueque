<?php
   require_once("includes/clase_usuario.php"); 
   //$usuario = new usuario();
   //echo $usuario->usuarioVerificar($_POST['txtLogin']);
   echo usuario::usuarioVerificar($_POST['txtLogin']);
?>
