﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript">
   gradiente('cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario1', '8080FF', '4D51F2', 'vertical', '', '' );
	gradiente('separador_menu_usuario2', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario3', '8080FF', '4D51F2', 'horizontal', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
</script>
<title>Datos Personales</title>
</head>

<body>
<?php 
require_once("includes/funciones.php");
  iniciarSesion();
?>
<div id="contenedor">
   <div id="main">
			   <div id="contenedor_formulario" style="padding-top:25px;">
				  <div id="div_formulario" class="formulario">
					<form id="frmUsuarios" name="frmUsuarios" method="post" action="usuarioBaja.php">
							 <div id="header_formulario">    
							 </div><!--cabecera-->
							 
							 <div class="tabla">
								
								<div class="fila" style="height:50px; padding:20px;">
								   <p class ="informacion"> Nos interesar saber cual es  el motivo por el que quieres darte de baja.</p> 
								   <p class ="informacion"> Por favor explicalo brevemente.</p>
								</div> <!--fila-->   
								
							 <div class="fila" style="height:110px;" >
								   <div class="columna_izquierda" style="height:80px; width:10%; font-size:14px; font-weight:600; padding-left:20px">Motivo</div>
								   <div class="columna_derecha">
									  <textarea class="campo" name="txtMotivo" id="txtMotivo" cols="55" rows="5" lang = "el Motivo"></textarea>
								   </div>
								</div> <!--fila-->   
				   
				   
							 </div> <!--tabla-->
							<div class ="botones_formulario"> 
							   <input class = "boton_comando" id ="cmdConfirmar" name="cmdConfirmar" type="button" value="Confirmar" onclick="validarPagina()"/>
							</div>
                            <input id="id_usuario" name = "id_usuario" type = "hidden" value = "<?php echo $_SESSION['id_usuario'] ?>"  >
					  </form>
					  </div><!--div_formulario-->   
			   </div><!--contenedor_formulario-->
   </div><!--main--> 
</div><!--contenedor-->
<script type="text/javascript">

function validarPagina()
{
  if (validarDatos(document.frmUsuarios,'') )
     return false;
  document.frmUsuarios.submit();
}

</script>

</body>
</html>
