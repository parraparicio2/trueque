<?php
  require_once("includes/clase_usuario.php");
  require_once("includes/funciones.php");
  usuario::usuarioRegistrar($_POST['txtLogin'],
                            $_POST['txtPassword'],
   							$_POST['txtNombre'],
							$_POST['txtCorreo'], 
							$_POST['txtTelefono'],
							$_POST['txtDireccion'],
							formatoFecha($_POST['txtFechaNacimiento']),
							$_POST['txtPregunta'],
							$_POST['txtRespuesta'],
							$_POST['cbEstado']);
  
 echo "<script>alert('Registro realizado satisfactoriamente') <script>"; 
 
 $body ="<p>Bienvenido a Tus Trueques.</p>
         <br>
         <p>ya eres miembro de la comunidad, te invitamos a que ingreses a tu cuenta y publiques tus articulos para realizar intercambios!</p>
         <br>
         <p>Datos para acceder a tu cuenta</p>
         <br>
         <p>Login: ". $_POST['txtLogin'] ." </p>
         <br>
         <p>Contrase�a: ".$_POST['txtPassword']."</p>";
        
    enviarCorreo($_POST['txtCorreo'], CORREO_USUARIO, CORREO_NOMBRE, 'Bienvenido a Tus Trueques', $body);                                          
   header("Location:index.php");                                      

?>
