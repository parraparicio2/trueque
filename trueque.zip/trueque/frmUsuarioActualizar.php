﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript">
   gradiente('cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario1', '8080FF', '4D51F2', 'vertical', '', '' );
	gradiente('separador_menu_usuario2', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario3', '8080FF', '4D51F2', 'horizontal', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
	
$(document).ready(function(){
   enviarFormulario('#cmdGuardar', 'usuarioActualizar.php', '#frmUsuarios', 'validarPagina()');
});  
	
</script>
<title>Datos Personales</title>
</head>

<body>
<?php
require_once('includes/clase_usuario.php');
require_once('includes/funciones.php');
  
  if ( iniciarSesion() )
   {  
	 $campo = usuario::usuarioBuscar($_SESSION['id_usuario']);
	 $txtNombre = $campo['nombre'];
	 $txtCorreo = $campo['correo'];
	 $txtTelefono = $campo['telefono'];
	 $txtFecha = transformarFecha($campo['fecha_nacimiento']);
	 $txtDireccion = $campo['direccion'];
	 $txtEstado = $campo['id_estado'];
	 $txtIdUsuario = $_SESSION['id_usuario'];
	 
	}
  else
     header('Location: login.php');
  	 
?>    
</div>


<div id="contenedor">
	<div id="main">
           <div id="contenedor_formulario" style="padding-top:25px;">
              <div id="div_formulario" class="formulario">
                <form id="frmUsuarios" name="frmUsuarios" method="post" >
                         <div id="header_formulario">    
                         </div><!--cabecera-->
                         
                         <div class="tabla">
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Nombre</div>
                               <div class="columna_derecha"><input name="txtNombre" type="text" class ="campo campo_largo" id="txtNombre" lang= "el nombre " maxlength="60" value ="<?php echo $txtNombre ?>"/></div>
                            </div> <!--fila-->   
               
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Correo El&eacute;ctronico</div>
                               <div class="columna_derecha"><input name="txtCorreo" type="text" class ="campo campo_mediano" id="txtCorreo" maxlength="30" value ="<?php echo $txtCorreo ?>"/> </div>
                            </div> <!--fila-->   
               
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Fecha de Nacimiento</div>
                               <div class="columna_derecha">
                                 <input name="txtFecha" type="text" class ="campo campo_fecha" id="txtFecha" maxlength="10" value = "<?php echo $txtFecha ?>" />
                                  <img src="images/calendar.gif" alt="" width="16" height="16"  id = "img_calendario"/> DD/MM/AAAA
                               </div><!--columna_derecha-->
                            </div> <!--fila-->   
                            
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Tel&eacute;fono</div>
                               <div class="columna_derecha"><input name="txtTelefono" type="text" class ="campo campo_largo" id="txtTelefono" maxlength="50" value ="<?php echo $txtTelefono ?>" /></div>
                            </div> <!--fila-->   
                            
                         <div class="fila" style="height:110px" >
                               <div class="columna_izquierda" style="height:80px">Direcci&oacute;n</div>
                               <div class="columna_derecha">
                                  <textarea class="campo" name="txtDireccion" id="txtDireccion" cols="35" rows="5"><?php echo $txtDireccion ?></textarea>
                               </div>
                            </div> <!--fila-->   
               
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Estado</div>
                               <div class="columna_derecha">
                                 <select class = "campo" style=" width:150px " name="cbEstado" id="cbEstado" >
                                    <?php 
                                       
                                       $result = usuario::listar_estados();
                                       while ($campo = mysqli_fetch_array($result, MYSQLI_ASSOC))
                                         {
                                    ?>
                                                <option value='<?php echo $campo['id_estado'];?>'><?php echo $campo['nombre'];?></option>
                                    <?php    
                                         }   
                                    ?>
                                  </select>  
                               </div>
                            </div> <!--fila-->      
               
                         <div id = "respuesta">
                         </div>

                         </div> <!--tabla-->
                        <div class ="botones_formulario"> 
                           <input class = "boton_comando" id ="cmdGuardar" name="cmdGuardar" type="button" value="Guardar" />
                        </div>
                        <input id="id_usuario" name = "id_usuario" type ="hidden"  value = "<?php echo $txtIdUsuario ?> "/>
                  </form>
                  </div><!--div_formulario-->   
                  
           </div><!--contenedor_formulario-->
	</div><!--main-->
</div><!--contenedor-->
<script type="text/javascript">
  seleccionarCombo('cbEstado','<?php echo $txtEstado?>')

function validarPagina()
{

  if (validarDatos(document.frmUsuarios,'') )
     return false;
	 
 	 
  if (validarFecha('txtFecha') == false)
      return false;	 
	 

  //document.frmUsuarios.cmdGuardar.setAttribute("type", "submit");	 
//  document.frmUsuarios.submit();
   return true;
   
}

  Calendar.setup
  (
    {
      inputField     :    "txtFecha",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario",
      singleClick    :    true,
      step           :    2  
	                
	}
  );

</script>

</body>
</html>
