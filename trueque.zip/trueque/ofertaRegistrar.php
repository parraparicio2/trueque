<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250" />
<title></title>
</head>
<?php
  require_once('includes/clase_oferta.php');
  require_once('configuracion/configurar.php');
  foreach($_POST['chPublicacion'] as $valor) 
	{
      $oferta = oferta::ofertaRegistrar($_POST['id_publicacion'], $valor, $_POST['id_usuario']);
	}
?>

<body>
 <script type="text/javascript">
    alert('Oferta realizada satisfactoriamente');
	window.location = '<?php echo PRINCIPAL ?>';
 </script>

</body>
</html>
