<?php
  require_once("includes/clase_usuario.php");
  require_once("includes/funciones.php");
  $mensaje = usuario::usuarioSeguridad($_POST['id_usuario'],
                             $_POST['txtPassword'],
							 $_POST['txtPregunta'],
							 $_POST['txtRespuesta'] 
							 );
							 
  echo $mensaje;	
  						 
  							 
    //enviarCorreo($_POST['txtCorreo'], CORREO_USUARIO, CORREO_NOMBRE, 'Bienvenido a Tus Trueques', $body);                                          
                                         

?>
