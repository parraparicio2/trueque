<?php
  require_once('includes/clase_usuario.php'); 

  $usuario = usuario::usuarioSesion($_POST['txtLogin'], $_POST['txtPassword']);
	  if ($usuario)
	    {   
         session_start();
         $_SESSION['id_usuario']  = $usuario['id_usuario'];
         $_SESSION['login'] = trim($usuario['login']);
		 $_SESSION['pagina_usuario']  = "";
		 $_SESSION['logout'] = "<a class='hipervinculo' href='logout.php'>".$_SESSION['login']." (Salir)</a>";
		 echo "<script> $('#login').dialog('close');</script>";
         echo "<script>document.forms[0].id_usuario.value = ".$usuario['id_usuario']."</script>";
		}
	  else
	     {
			  echo "<script>alert('Login o Contrasen&ntilde;a Invalida')</script>";
			  echo "<script>
						  document.frmLogin.txtLogin.value = '';
						  document.frmLogin.txtPassword.value = '';
			        </script>";
		  }
?>
