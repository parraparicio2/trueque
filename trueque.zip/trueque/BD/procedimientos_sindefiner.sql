DROP PROCEDURE IF EXISTS  `sp_actualizar_usuarios` ;

DELIMITER $$

CREATE  PROCEDURE `sp_actualizar_usuarios`(
        in p_id_usuario bigint,
        IN p_nombre CHAR(60),
        IN p_correo CHAR(30),
        IN p_telefono CHAR(50),
        IN p_direccion CHAR(255),
        IN p_fecha_nacimiento DATE,
        IN p_id_estado INTEGER,
        OUT r_mensaje VARCHAR(50)
        
    )
BEGIN
   update tbl_usuario
      set nombre    = p_nombre,
          correo    = p_correo,
          telefono  = p_telefono,
          direccion = p_direccion,
          fecha_nacimiento = p_fecha_nacimiento,
          id_estado = p_id_estado
    where id_usuario = p_id_usuario;    
           
         
   SET r_mensaje = 'Datos actualizados satisfactoriamente';                         
   
   SELECT r_mensaje; 
END $$
DELIMITER ;

/* Procedure structure for procedure `sp_baja_usuario` */

DROP PROCEDURE IF EXISTS  `sp_baja_usuario` ;

DELIMITER $$

CREATE  PROCEDURE `sp_baja_usuario`(
   in p_id_usuario bigint,
   in p_motivo varchar(200),
   out r_mensaje varchar(100)    
)
begin
   insert into tbl_baja
               (
               id_usuario,
               motivo,
               fecha
               )
        values (
                p_id_usuario,
                p_motivo,
                current_date()
               );   
               
               
   update tbl_usuario 
      set activo = false
    where id_usuario = p_id_usuario;
    
                    
   Set r_mensaje = 'El Usuario ha sido dado de baja';  
   
   select r_mensaje;                   
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_buscarPublicacionPorId` */

DROP PROCEDURE IF EXISTS  `sp_buscarPublicacionPorId` ;

DELIMITER $$

CREATE  PROCEDURE `sp_buscarPublicacionPorId`(
   in p_id_publicacion bigint/*
   out r_id_publicacion BIGINT,
   OUT r_id_subcategoria INT,
   OUT r_id_usuario BIGINT,
   OUT r_titulo VARCHAR(100),
   OUT r_fecha_publicacion DATE,
   OUT r_descripcion LONGBLOB,
   OUT r_descripcion_estado VARCHAR(30),  
   OUT r_id_foto bigint,
   OUT r_foto LONGBLOB,
   OUT r_tipo VARCHAR(30),
   OUT r_tamano INT*/
)
begin
declare r_id_publicacion bigint;
declare r_id_subcategoria int;
declare r_id_usuario bigint;
DECLARE r_login char(20);
declare r_titulo varchar(100);
declare r_fecha_publicacion date;
declare r_descripcion longblob;
declare r_descripcion_estado varchar(30);  
DECLARE r_id_foto LONGBLOB;
declare r_foto longblob;
declare r_tipo varchar(30);
declare r_tamano int;
DECLARE r_nombre_estado varchar(50);
    select id_publicacion,
           id_subcategoria,
           id_usuario,
           titulo,
           fecha_publicacion
      INTO r_id_publicacion,
           r_id_subcategoria,
           r_id_usuario,
           r_titulo,
           r_fecha_publicacion
      from tbl_publicacion 
     where id_publicacion = p_id_publicacion;
     
     select a.descripcion,
            b.descripcion  
       into r_descripcion,
            r_descripcion_estado
       from tbl_articulo a 
       join tbl_estado_articulo b
         on a.id_estado_articulo = b.id_estado_articulo
      where a.id_publicacion = p_id_publicacion;
      
      select id_fotos, 
             foto,
             tipo,
             tamano
        into r_id_foto,
             r_foto,
             r_tipo,
             r_tamano    
        from tbl_fotos
       where id_publicacion = p_id_publicacion
       limit 1,1;  
       
       select u.login,
              e.nombre              
         into r_login,
              r_nombre_estado
         from tbl_usuario u
         join tbl_estados e
           on u.id_estado = e.id_estado 
        where id_usuario = r_id_usuario;  
              
              
   select  r_id_publicacion,
           r_id_subcategoria,
           r_id_usuario,
           r_titulo,
           r_fecha_publicacion,           
           r_descripcion,
           r_descripcion_estado,
	   r_id_foto,
           r_foto,
           r_tipo,
           r_tamano,
           r_login,
           r_nombre_estado;  
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_fotos_publicacion` */

DROP PROCEDURE IF EXISTS  `sp_buscar_fotos_publicacion` ;

DELIMITER $$

CREATE  PROCEDURE `sp_buscar_fotos_publicacion`(
   in p_id_publicacion bigint
)
begin
   select id_fotos
     from tbl_fotos      
    where id_publicacion = p_id_publicacion;
      
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_foto_id` */

DROP PROCEDURE IF EXISTS  `sp_buscar_foto_id` ;

DELIMITER $$

CREATE  PROCEDURE `sp_buscar_foto_id`(

  in p_id_fotos bigint

)
begin

   select id_fotos,

          foto,

          tipo

     from tbl_fotos

    where id_fotos = p_id_fotos;           

end $$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_password` */

 DROP PROCEDURE IF EXISTS  `sp_buscar_password` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_buscar_password`(
  in p_id_usuario bigint,
  in p_password char(20),
  out r_valido boolean
)
begin
declare v_contador integer; 
   select count(*) into v_contador
     from tbl_usuario 
    where id_usuario = p_id_usuario
      and pass = md5(p_password);
      
    if v_contador = 0 then
       set r_valido = false;
    else
       set r_valido = true;
    end if;  
    
    select r_valido;
    
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_preguntas` */

 DROP PROCEDURE IF EXISTS  `sp_buscar_preguntas` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_buscar_preguntas`(
   in p_id_publicacion bigint
)
begin
   select a.id_pregunta,
          a.id_usuario,
          b.login,
          a.id_publicacion,
          a.pregunta,
          a.respuesta,
          a.fecha,
          a.hora  
     from tbl_preguntas a
     join tbl_usuario b
       on a.id_usuario = b.id_usuario
     
    where a.id_publicacion = p_id_publicacion;          
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_usuarios` */

 DROP PROCEDURE IF EXISTS  `sp_buscar_usuarios` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_buscar_usuarios`(
   in p_id_usuario bigint
)
BEGIN
   select login,
          nombre,
          correo,
          telefono,
          direccion,
          fecha_nacimiento,
          fecha_registro,
          id_estado
     from tbl_usuario
    where id_usuario = p_id_usuario;
         
END $$
DELIMITER ;

/* Procedure structure for procedure `sp_cambiar_password` */

DROP PROCEDURE IF EXISTS  `sp_cambiar_password` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_cambiar_password`(
   in p_id_usuario bigint,
   in p_password char(20),
   in p_pregunta char(100),
   in p_respuesta char(100),
   out r_mensaje varchar(100)
)
begin
   update tbl_usuario 
      set pass = md5(p_password),
          pregunta = p_pregunta,
          respuesta = p_respuesta
   where id_usuario = p_id_usuario;   
   
   Set r_mensaje = 'Contrase�a actualizada satisfactoriamente';  
   
   select r_mensaje;
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_contar_publicacion_usuario` */

DROP PROCEDURE IF EXISTS  `sp_contar_publicacion_usuario` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_contar_publicacion_usuario`(
   in p_id_usuario bigint
)
BEGIN
   select count(*) as cantidad
     from tbl_publicacion
    where id_usuario = p_id_usuario
      and activa = 1;  
END $$
DELIMITER ;

/* Procedure structure for procedure `sp_estado_articulo` */

DROP PROCEDURE IF EXISTS  `sp_estado_articulo` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_estado_articulo`(
  in p_id_estado_articulo integer
)
begin
   if (p_id_estado_articulo is null) then
       select id_estado_articulo,
              descripcion
         from tbl_estado_articulo;      
   else
       SELECT id_estado_articulo,
              descripcion
         FROM tbl_estado_articulo
        where id_estado_articulo = p_id_estado_articulo;      
   
   end if; 
  
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_iniciar_sesion` */

 DROP PROCEDURE IF EXISTS  `sp_iniciar_sesion` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_iniciar_sesion`(
  in p_login char(20),
  in p_password char(20)
)
begin
   select id_usuario,
          login          
     from tbl_usuario
   where  pass = md5(p_password) 
     and login = p_login
     and activo = true;      
          
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_listar_categorias` */

 DROP PROCEDURE IF EXISTS  `sp_listar_categorias` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_listar_categorias`()
begin
  select id_categoria,
         nombre 
    from tbl_categoria
    order by 2;
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_listar_estados` */

DROP PROCEDURE IF EXISTS  `sp_listar_estados` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_listar_estados`(
   in p_id_pais int
)
begin
   SELECT id_estado,
          nombre
     FROM tbl_estados 
     where id_pais = p_id_pais
     order by nombre;
     
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_listar_subcategorias` */

DROP PROCEDURE IF EXISTS  `sp_listar_subcategorias` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_listar_subcategorias`(
   in p_id_categoria integer
)
begin
   select id_subcategoria,
          nombre 
     from tbl_subcategoria       
   where id_categoria = p_id_categoria
   order by 2;       
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_listar_subcategorias_todas` */

DROP PROCEDURE IF EXISTS  `sp_listar_subcategorias_todas` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_listar_subcategorias_todas`()
begin
  SELECT id_categoria,
         id_subcategoria,
         nombre 
    FROM tbl_subcategoria
    order by 3;       
   
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_publicacion_usuario` */

DELIMITER $$

DROP PROCEDURE IF EXISTS `sp_publicacion_usuario`$$


CREATE  PROCEDURE `sp_publicacion_usuario`(
   IN p_id_usuario BIGINT,
   IN p_inicio_registro INT,
   IN p_cantidad INT
)
BEGIN
    SELECT a.id_publicacion, 
           a.titulo,
           a.fecha_publicacion,
           a.activa,
           DATEDIFF(a.fecha_vencimiento, CURRENT_DATE()) AS dias
      FROM tbl_publicacion a 
     WHERE a.id_usuario = p_id_usuario 
       AND a.activa = 1
     ORDER BY a.fecha_publicacion DESC
     LIMIT 0, 10;
END$$


DELIMITER ;
/* Procedure structure for procedure `sp_registrar_publicacion` */

 DROP PROCEDURE IF EXISTS  `sp_registrar_publicacion` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_registrar_publicacion`(
   in p_id_subcategoria int,
   in p_id_usuario int,
   in p_titulo char(100),
   in p_fecha_publicacion date,
   in p_dias_publicacion int,
   in p_descripcion longblob,
   in p_id_estado_articulo int,
   in p_foto_1 longblob,
   in p_tipo_1 varchar(30),
   in p_tamano_1 int,
   IN p_foto_2 LONGBLOB,
   IN p_tipo_2 VARCHAR(30),
   IN p_tamano_2 INT,
   IN p_foto_3 LONGBLOB,
   IN p_tipo_3 VARCHAR(30),
   IN p_tamano_3 INT,
  out r_mensaje varchar(100)
)
begin
declare v_id_publicacion bigint;
   insert into tbl_publicacion
               (
               id_subcategoria,
               id_usuario,
               titulo,
               fecha_publicacion,
               fecha_vencimiento,
               activa,
               fecha_hora
               )
        values (
               p_id_subcategoria,
               p_id_usuario,
               p_titulo,
               current_date(),
               adddate(current_date(), interval p_dias_publicacion day),
               1, 
               current_timestamp()
               );   
               
   set v_id_publicacion = LAST_INSERT_ID();
   insert into tbl_articulo
               (
                id_publicacion,
                id_estado_articulo,
                descripcion,
                precio,
                existencia
               )
        values (
                v_id_publicacion,
                p_id_estado_articulo,
                p_descripcion,
                0,
                1
                );
                
   if (p_foto_1 <>'') then              
	   insert into tbl_fotos
		       (
		       id_publicacion,
		       foto,
		       tipo,
		       tamano  
		       )
		values (
			v_id_publicacion,
			p_foto_1,
			p_tipo_1,
			p_tamano_1
			);
    end if;			
   IF (p_foto_2 <>'') THEN              
	   INSERT INTO tbl_fotos
		       (
		       id_publicacion,
		       foto,
		       tipo,
		       tamano  
		       )
		VALUES (
			v_id_publicacion,
			p_foto_2,
			p_tipo_2,
			p_tamano_2
			);
    END IF;			
   IF (p_foto_3 <>'') THEN              
	   INSERT INTO tbl_fotos
		       (
		       id_publicacion,
		       foto,
		       tipo,
		       tamano  
		       )
		VALUES (
			v_id_publicacion,
			p_foto_3,
			p_tipo_3,
			p_tamano_3
			);
    END IF;			
                
   set r_mensaje = 'Publicaci�n realizada satisfactoriamente';  
   
   select r_mensaje;              
end $$
DELIMITER ;

/* Procedure structure for procedure `sp_registrar_usuarios` */

 DROP PROCEDURE IF EXISTS  `sp_registrar_usuarios` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_registrar_usuarios`(
        IN p_login CHAR(20),
        IN p_pass CHAR(20),
        IN p_nombre CHAR(60),
        IN p_correo CHAR(30),
        IN p_telefono CHAR(50),
        IN p_direccion CHAR(255),
        IN p_fecha_nacimiento DATE,
        in p_pregunta char(100),
        in p_respuesta char(100),
        IN p_id_estado INTEGER,
        out r_mensaje varchar(50)
        
    )
BEGIN
   if not (exists(select login 
                    from tbl_usuario  
                   where login = p_login )) then
                    
		INSERT INTO tbl_usuario
						(
						login,
						pass,
						nombre,
						correo,
						telefono,
						direccion,
						fecha_nacimiento,
						fecha_registro,
						pregunta,
						respuesta,
						id_estado,
			  		   activo  
			  	      )
			  VALUES (
						p_login,
						md5(p_pass),
						p_nombre,
						p_correo,
						p_telefono,
						p_direccion,
						p_fecha_nacimiento,
						CURRENT_DATE(),
						p_pregunta,
						p_respuesta, 
						p_id_estado,
						1
						);
					
		     SET r_mensaje = 'Registro Ingresado satisfactoriamente';                         
        end if;                   
   
   select r_mensaje; 
END $$
DELIMITER ;

/* Procedure structure for procedure `sp_verificar_login` */

 DROP PROCEDURE IF EXISTS  `sp_verificar_login` ;

DELIMITER $$

 CREATE  PROCEDURE `sp_verificar_login`(
   IN p_login CHAR(20), 
   OUT r_existe BOOL
)
BEGIN
declare v_contador integer;
   
   SELECT count(*) 
    into v_contador
     FROM tbl_usuario 
    WHERE login = p_login;
   
   if (v_contador > 0) then
      set r_existe = true;
   else
      set r_existe = false;
   end if;    
            
   SELECT r_existe;             
END $$
DELIMITER ;

40101 SET SQL_MODE=@OLD_SQL_MODE */;
40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
