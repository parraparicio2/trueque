CREATE TABLE tbl_articulo (
  id_articulo BIGINT NOT NULL AUTO_INCREMENT,
  id_publicacion BIGINT NOT NULL,
  id_estado_articulo TINYINT NOT NULL,
  descripcion LONGBLOB NULL,
  precio DECIMAL NOT NULL,
  existencia DECIMAL ZEROFILL NOT NULL,
  PRIMARY KEY(id_articulo),
  INDEX index_id_pub_articulo(id_publicacion)
)ENGINE=MyISAM;

CREATE TABLE tbl_baja (
  id_baja INTEGER NOT NULL AUTO_INCREMENT,
  id_usuario BIGINT NOT NULL,
  motivo VARCHAR(200) NULL,
  fecha DATE NULL,
  PRIMARY KEY(id_baja)
)ENGINE=MyISAM;

CREATE TABLE tbl_calificacion (
  id_calificacion INT NOT NULL,
  id_usuario BIGINT NOT NULL,
  id_tipo_calificacion TINYINT NOT NULL,
  comentario VARCHAR(1000) NOT NULL,
  PRIMARY KEY(id_calificacion)
)ENGINE=MyISAM;

CREATE TABLE tbl_categoria (
  id_categoria INT NOT NULL AUTO_INCREMENT,
  nombre CHAR(70) NOT NULL,
  PRIMARY KEY(id_categoria)
)ENGINE=MyISAM;

CREATE TABLE tbl_categoria_articulo (
  id_categoria_articulo INT NOT NULL AUTO_INCREMENT,
  id_subcategoria INT NOT NULL,
  id_categoria INT NOT NULL,
  PRIMARY KEY(id_categoria_articulo)
)ENGINE=MyISAM;

CREATE TABLE tbl_estados (
  id_estado INT NOT NULL AUTO_INCREMENT,
  id_pais INT NOT NULL,
  nombre CHAR(50) NOT NULL,
  PRIMARY KEY(id_estado)
)ENGINE=MyISAM;

CREATE TABLE tbl_estado_articulo (
  id_estado_articulo TINYINT NOT NULL AUTO_INCREMENT,
  descripcion CHAR(30) NOT NULL,
  PRIMARY KEY(id_estado_articulo)
)ENGINE=MyISAM;

CREATE TABLE tbl_fotos (
  id_fotos BIGINT NOT NULL AUTO_INCREMENT,
  id_publicacion BIGINT NOT NULL,
  foto LONGBLOB NOT NULL,
  PRIMARY KEY(id_fotos),
  INDEX index_id_publicacion(id_publicacion)
)ENGINE=MyISAM;

CREATE TABLE tbl_oferta (
  id_oferta BIGINT NOT NULL AUTO_INCREMENT,
  id_publicacion BIGINT NOT NULL,
  id_publicacion_oferta BIGINT NULL,
  aceptar_oferta BOOL NOT NULL,
  fecha_oferta DATE NOT NULL,
  activa BOOL NOT NULL,
  PRIMARY KEY(id_oferta),
  INDEX tbl_oferta_index1395(id_publicacion, id_publicacion_oferta)
)ENGINE=MyISAM;

CREATE TABLE tbl_pais (
  id_pais INT NOT NULL AUTO_INCREMENT,
  nombre CHAR(50) NOT NULL,
  PRIMARY KEY(id_pais)
)ENGINE=MyISAM;

CREATE TABLE tbl_preguntas (
  id_pregunta INT NOT NULL AUTO_INCREMENT,
  id_usuario BIGINT NOT NULL,
  id_publicacion BIGINT NOT NULL,
  pregunta VARCHAR(1000) NOT NULL,
  respuesta VARCHAR(1000) NULL,
  fecha DATE NULL,
  hora TIME NULL,
  PRIMARY KEY(id_pregunta)
)ENGINE=MyISAM;

CREATE TABLE tbl_publicacion (
  id_publicacion BIGINT NOT NULL AUTO_INCREMENT,
  id_categoria_articulo INT NOT NULL,
  id_usuario BIGINT NOT NULL,
  titulo CHAR(100) NULL,
  fecha_publicacion DATE NOT NULL,
  fecha_vencimiento DATE NULL,
  activa BOOL NOT NULL,
  fecha_hora TIMESTAMP NULL,
  PRIMARY KEY(id_publicacion),
  INDEX index_fecha_hora(fecha_hora),
  INDEX fecha(fecha_publicacion)
)ENGINE=MyISAM;

CREATE TABLE tbl_subcategoria (
  id_subcategoria INT NOT NULL AUTO_INCREMENT,
  nombre CHAR(100) NULL,
  PRIMARY KEY(id_subcategoria)
)ENGINE=MyISAM;

CREATE TABLE tbl_tipo_calificacion (
  id_tipo_calificacion TINYINT NOT NULL AUTO_INCREMENT,
  descripcion CHAR(50) NOT NULL,
  PRIMARY KEY(id_tipo_calificacion)
)ENGINE=MyISAM;

CREATE TABLE tbl_usuario (
  id_usuario BIGINT NOT NULL AUTO_INCREMENT,
  id_estado INT NOT NULL,
  login CHAR(20) NOT NULL,
  pass CHAR(100) NOT NULL,
  nombre CHAR(60) NOT NULL,
  correo CHAR(30) NOT NULL,
  telefono CHAR(50) NOT NULL,
  direccion CHAR(255) NOT NULL,
  fecha_nacimiento DATE NULL,
  fecha_registro DATE NOT NULL,
  activo BOOL NOT NULL,
  pregunta CHAR(100) NULL,
  respuesta CHAR(100) NULL,
  PRIMARY KEY(id_usuario),
  INDEX Index_login_pass(login, pass),
  UNIQUE INDEX index_login(login)
)ENGINE=MyISAM;


