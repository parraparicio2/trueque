/*
SQLyog Ultimate v9.02 
MySQL - 5.5.16-log : Database - bdtrueque
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bdtrueque` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci */;

USE `bdtrueque`;

/*Table structure for table `tbl_articulo` */

DROP TABLE IF EXISTS `tbl_articulo`;

CREATE TABLE `tbl_articulo` (
  `id_articulo` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_publicacion` bigint(20) NOT NULL,
  `id_estado_articulo` tinyint(4) NOT NULL,
  `descripcion` longblob,
  `precio` decimal(10,0) NOT NULL,
  `existencia` decimal(10,0) unsigned zerofill NOT NULL,
  PRIMARY KEY (`id_articulo`),
  KEY `index_id_pub_articulo` (`id_publicacion`)
) ENGINE=MyISAM AUTO_INCREMENT=170 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_baja` */

DROP TABLE IF EXISTS `tbl_baja`;

CREATE TABLE `tbl_baja` (
  `id_baja` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) NOT NULL,
  `motivo` varchar(200) COLLATE latin1_spanish_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id_baja`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_calificacion` */

DROP TABLE IF EXISTS `tbl_calificacion`;

CREATE TABLE `tbl_calificacion` (
  `id_calificacion` int(11) NOT NULL,
  `id_usuario` bigint(20) NOT NULL,
  `id_tipo_calificacion` tinyint(4) NOT NULL,
  `comentario` varchar(1000) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_calificacion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_categoria` */

DROP TABLE IF EXISTS `tbl_categoria`;

CREATE TABLE `tbl_categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` char(70) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_estado_articulo` */

DROP TABLE IF EXISTS `tbl_estado_articulo`;

CREATE TABLE `tbl_estado_articulo` (
  `id_estado_articulo` tinyint(4) NOT NULL AUTO_INCREMENT,
  `descripcion` char(30) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_estado_articulo`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_estados` */

DROP TABLE IF EXISTS `tbl_estados`;

CREATE TABLE `tbl_estados` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `id_pais` int(11) NOT NULL,
  `nombre` char(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_fotos` */

DROP TABLE IF EXISTS `tbl_fotos`;

CREATE TABLE `tbl_fotos` (
  `id_fotos` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_publicacion` bigint(20) NOT NULL,
  `foto` longblob NOT NULL,
  `nombre` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `tipo` varchar(30) COLLATE latin1_spanish_ci DEFAULT NULL,
  `tamano` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_fotos`),
  KEY `index_id_publicacion` (`id_publicacion`)
) ENGINE=MyISAM AUTO_INCREMENT=161 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_oferta` */

DROP TABLE IF EXISTS `tbl_oferta`;

CREATE TABLE `tbl_oferta` (
  `id_oferta` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_publicacion` bigint(20) NOT NULL,
  `id_publicacion_oferta` bigint(20) DEFAULT NULL,
  `aceptar_oferta` tinyint(1) NOT NULL,
  `fecha_oferta` date NOT NULL,
  `activa` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_oferta`),
  KEY `tbl_oferta_index1395` (`id_publicacion`,`id_publicacion_oferta`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_pais` */

DROP TABLE IF EXISTS `tbl_pais`;

CREATE TABLE `tbl_pais` (
  `id_pais` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` char(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_pais`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_preguntas` */

DROP TABLE IF EXISTS `tbl_preguntas`;

CREATE TABLE `tbl_preguntas` (
  `id_pregunta` int(11) NOT NULL AUTO_INCREMENT,
  `id_publicacion` bigint(20) NOT NULL,
  `pregunta` varchar(1000) COLLATE latin1_spanish_ci NOT NULL,
  `respuesta` varchar(1000) COLLATE latin1_spanish_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `id_usuario` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_pregunta`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_publicacion` */

DROP TABLE IF EXISTS `tbl_publicacion`;

CREATE TABLE `tbl_publicacion` (
  `id_publicacion` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_subcategoria` int(11) NOT NULL,
  `id_usuario` bigint(20) NOT NULL,
  `titulo` char(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `fecha_publicacion` date NOT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `activa` tinyint(1) NOT NULL,
  `fecha_hora` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_publicacion`),
  KEY `index_fecha_hora` (`fecha_hora`),
  KEY `fecha` (`fecha_publicacion`),
  KEY `idx_publicacion_activa` (`id_usuario`,`activa`)
) ENGINE=MyISAM AUTO_INCREMENT=174 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_subcategoria` */

DROP TABLE IF EXISTS `tbl_subcategoria`;

CREATE TABLE `tbl_subcategoria` (
  `id_subcategoria` int(11) NOT NULL AUTO_INCREMENT,
  `id_categoria` int(11) NOT NULL,
  `nombre` char(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_subcategoria`)
) ENGINE=MyISAM AUTO_INCREMENT=220 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_tipo_calificacion` */

DROP TABLE IF EXISTS `tbl_tipo_calificacion`;

CREATE TABLE `tbl_tipo_calificacion` (
  `id_tipo_calificacion` tinyint(4) NOT NULL AUTO_INCREMENT,
  `descripcion` char(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id_tipo_calificacion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/*Table structure for table `tbl_usuario` */

DROP TABLE IF EXISTS `tbl_usuario`;

CREATE TABLE `tbl_usuario` (
  `id_usuario` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_estado` int(11) NOT NULL,
  `login` char(20) COLLATE latin1_spanish_ci NOT NULL,
  `pass` char(100) COLLATE latin1_spanish_ci NOT NULL,
  `nombre` char(60) COLLATE latin1_spanish_ci NOT NULL,
  `correo` char(30) COLLATE latin1_spanish_ci NOT NULL,
  `telefono` char(50) COLLATE latin1_spanish_ci NOT NULL,
  `direccion` char(255) COLLATE latin1_spanish_ci NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `fecha_registro` date NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `pregunta` char(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `respuesta` char(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `tbl_usuario_index1415` (`login`),
  KEY `tbl_usuario_login` (`login`,`pass`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

/* Trigger structure for table `tbl_publicacion` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `trg_eliminar_publicacion` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `trg_eliminar_publicacion` AFTER DELETE ON `tbl_publicacion` FOR EACH ROW BEGIN
        DELETE FROM tbl_articulo WHERE id_publicacion = OLD.id_publicacion;
        DELETE FROM tbl_fotos WHERE id_publicacion = OLD.id_publicacion;
    END */$$


DELIMITER ;

/* Procedure structure for procedure `sp_actualizar_usuarios` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_actualizar_usuarios` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizar_usuarios`(
        in p_id_usuario bigint,
        IN p_nombre CHAR(60),
        IN p_correo CHAR(30),
        IN p_telefono CHAR(50),
        IN p_direccion CHAR(255),
        IN p_fecha_nacimiento DATE,
        IN p_id_estado INTEGER,
        OUT r_mensaje VARCHAR(50)
        
    )
BEGIN
   update tbl_usuario
      set nombre    = p_nombre,
          correo    = p_correo,
          telefono  = p_telefono,
          direccion = p_direccion,
          fecha_nacimiento = p_fecha_nacimiento,
          id_estado = p_id_estado
    where id_usuario = p_id_usuario;    
           
         
   SET r_mensaje = 'Datos actualizados satisfactoriamente';                         
   
   SELECT r_mensaje; 
END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_baja_usuario` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_baja_usuario` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_baja_usuario`(
   in p_id_usuario bigint,
   in p_motivo varchar(200),
   out r_mensaje varchar(100)    
)
begin
   insert into tbl_baja
               (
               id_usuario,
               motivo,
               fecha
               )
        values (
                p_id_usuario,
                p_motivo,
                current_date()
               );   
               
               
   update tbl_usuario 
      set activo = false
    where id_usuario = p_id_usuario;
    
                    
   Set r_mensaje = 'El Usuario ha sido dado de baja';  
   
   select r_mensaje;                   
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_buscarPublicacionPorId` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_buscarPublicacionPorId` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscarPublicacionPorId`(
   in p_id_publicacion bigint
)
begin
declare r_id_publicacion bigint;
declare r_id_subcategoria int;
declare r_id_usuario bigint;
DECLARE r_login char(20);
declare r_titulo varchar(100);
declare r_fecha_publicacion date;
declare r_descripcion longblob;
declare r_descripcion_estado varchar(30);  
DECLARE r_id_foto LONGBLOB;
declare r_foto longblob;
declare r_tipo varchar(30);
declare r_tamano int;
DECLARE r_nombre_estado varchar(50);
declare r_fecha_registro date;
    select id_publicacion,
           id_subcategoria,
           id_usuario,
           titulo,
           fecha_publicacion
      INTO r_id_publicacion,
           r_id_subcategoria,
           r_id_usuario,
           r_titulo,
           r_fecha_publicacion
      from tbl_publicacion 
     where id_publicacion = p_id_publicacion;
     
     select a.descripcion,
            b.descripcion  
       into r_descripcion,
            r_descripcion_estado
       from tbl_articulo a 
       join tbl_estado_articulo b
         on a.id_estado_articulo = b.id_estado_articulo
      where a.id_publicacion = p_id_publicacion;
      
      select id_fotos, 
             foto,
             tipo,
             tamano
        into r_id_foto,
             r_foto,
             r_tipo,
             r_tamano    
        from tbl_fotos
       where id_publicacion = p_id_publicacion
       limit 1,1;  
       
       select u.login,
              u.fecha_registro,              
              e.nombre
         into r_login,
              r_fecha_registro,
              r_nombre_estado
         from tbl_usuario u
         join tbl_estados e
           on u.id_estado = e.id_estado 
        where id_usuario = r_id_usuario;  
              
              
   select  r_id_publicacion,
           r_id_subcategoria,
           r_id_usuario,
           r_titulo,
           r_fecha_publicacion,           
           r_descripcion,
           r_descripcion_estado,
	   r_id_foto,
           r_foto,
           r_tipo,
           r_tamano,
           r_login,
           r_fecha_registro,
           r_nombre_estado;  
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_fotos_publicacion` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_buscar_fotos_publicacion` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_fotos_publicacion`(
   in p_id_publicacion bigint
)
begin
   select id_fotos
     from tbl_fotos      
    where id_publicacion = p_id_publicacion;
      
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_foto_id` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_buscar_foto_id` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_foto_id`(
  in p_id_fotos bigint
)
begin
   select id_fotos,
          foto,
          tipo
     from tbl_fotos
    where id_fotos = p_id_fotos;           
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_password` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_buscar_password` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_password`(
  in p_id_usuario bigint,
  in p_password char(20),
  out r_valido boolean
)
begin
declare v_contador integer; 
   select count(*) into v_contador
     from tbl_usuario 
    where id_usuario = p_id_usuario
      and pass = md5(p_password);
      
    if v_contador = 0 then
       set r_valido = false;
    else
       set r_valido = true;
    end if;  
    
    select r_valido;
    
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_preguntas` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_buscar_preguntas` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_preguntas`(
   in p_id_publicacion bigint
)
begin
   select a.id_pregunta,
          a.id_usuario,
          b.login,
          a.id_publicacion,
          a.pregunta,
          a.respuesta,
          a.fecha,
          a.hora  
     from tbl_preguntas a
     join tbl_usuario b
       on a.id_usuario = b.id_usuario
     
    where a.id_publicacion = p_id_publicacion;          
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_buscar_usuarios` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_buscar_usuarios` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_buscar_usuarios`(
   in p_id_usuario bigint
)
BEGIN
   select login,
          nombre,
          correo,
          telefono,
          direccion,
          fecha_nacimiento,
          fecha_registro,
          id_estado
     from tbl_usuario
    where id_usuario = p_id_usuario;
         
END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_cambiar_password` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_cambiar_password` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_cambiar_password`(
   in p_id_usuario bigint,
   in p_password char(20),
   in p_pregunta char(100),
   in p_respuesta char(100),
   out r_mensaje varchar(100)
)
begin
   update tbl_usuario 
      set pass = md5(p_password),
          pregunta = p_pregunta,
          respuesta = p_respuesta
   where id_usuario = p_id_usuario;   
   
   Set r_mensaje = 'ContraseÃ±a actualizada satisfactoriamente';  
   
   select r_mensaje;
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_contar_publicacion_usuario` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_contar_publicacion_usuario` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_contar_publicacion_usuario`(
   in p_id_usuario bigint
)
BEGIN
   select count(*) as cantidad
     from tbl_publicacion
    where id_usuario = p_id_usuario
      and activa = 1;  
END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_estado_articulo` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_estado_articulo` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_estado_articulo`(
  in p_id_estado_articulo integer
)
begin
   if (p_id_estado_articulo is null) then
       select id_estado_articulo,
              descripcion
         from tbl_estado_articulo;      
   else
       SELECT id_estado_articulo,
              descripcion
         FROM tbl_estado_articulo
        where id_estado_articulo = p_id_estado_articulo;      
   
   end if; 
  
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_iniciar_sesion` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_iniciar_sesion` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_iniciar_sesion`(
  in p_login char(20),
  in p_password char(20)
)
begin
   select id_usuario,
          login          
     from tbl_usuario
   where  pass = md5(p_password) 
     and login = p_login
     and activo = true;      
          
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_listar_categorias` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_listar_categorias` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_categorias`()
begin
  select id_categoria,
         nombre 
    from tbl_categoria
    order by 2;
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_listar_estados` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_listar_estados` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_estados`(
   in p_id_pais int
)
begin
   SELECT id_estado,
          nombre
     FROM tbl_estados 
     where id_pais = p_id_pais
     order by nombre;
     
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_listar_subcategorias` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_listar_subcategorias` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_subcategorias`(
   in p_id_categoria integer
)
begin
   select id_subcategoria,
          nombre 
     from tbl_subcategoria       
   where id_categoria = p_id_categoria
   order by 2;       
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_listar_subcategorias_todas` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_listar_subcategorias_todas` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listar_subcategorias_todas`()
begin
  SELECT id_categoria,
         id_subcategoria,
         nombre 
    FROM tbl_subcategoria
    order by 3;       
   
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_preguntas_responder` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_preguntas_responder` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_preguntas_responder`(
  in p_id_usuario bigint
)
begin
   select a.id_pregunta,
          a.id_publicacion,
          a.id_pregunta,
          b.titulo,
          a.pregunta,
          b.id_usuario,
          a.fecha
     from tbl_preguntas a
     join tbl_publicacion b
       on a.id_publicacion = b.id_publicacion
    where b.id_usuario = p_id_usuario
      and a.respuesta = ''     
      order by a.id_publicacion, a.fecha; 
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_publicacion_usuario` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_publicacion_usuario` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_publicacion_usuario`(
   in p_id_usuario bigint,
   in p_inicio_registro int,
   in p_cantidad int
)
begin
    select a.id_publicacion, 
           a.titulo,
           a.fecha_publicacion,
           a.activa,
           DATEDIFF(a.fecha_vencimiento, current_date()) as dias,
           (SELECT b.id_fotos FROM tbl_fotos b WHERE b.id_publicacion = a.id_publicacion LIMIT 1) AS  id_fotos
      from tbl_publicacion a 
     where a.id_usuario = p_id_usuario 
       and a.activa = 1
     order by a.fecha_publicacion desc
     limit p_inicio_registro, p_cantidad;
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_registrar_preguntas` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_registrar_preguntas` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_preguntas`(
   in p_id_publicacion bigint,
   in p_id_usuario bigint,
   in p_pregunta varchar(1000),
   OUT r_mensaje VARCHAR(100)
)
begin
   insert into tbl_preguntas
               (
               id_publicacion,
               id_usuario,
               pregunta,
               respuesta,
               fecha
               )
        values (
               p_id_publicacion,
               p_id_usuario,
               p_pregunta,
               '',
               current_date()  
               );  
   SET r_mensaje = 'Se ha enviado su pregunta al autor de la publicación.';                 
   
   select r_mensaje;
                  
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_registrar_publicacion` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_registrar_publicacion` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_publicacion`(
   in p_id_subcategoria int,
   in p_id_usuario int,
   in p_titulo char(100),
   in p_fecha_publicacion date,
   in p_dias_publicacion int,
   in p_descripcion longblob,
   in p_id_estado_articulo int,
   in p_foto_1 longblob,
   in p_tipo_1 varchar(30),
   in p_tamano_1 int,
   IN p_foto_2 LONGBLOB,
   IN p_tipo_2 VARCHAR(30),
   IN p_tamano_2 INT,
   IN p_foto_3 LONGBLOB,
   IN p_tipo_3 VARCHAR(30),
   IN p_tamano_3 INT,
  out r_mensaje varchar(100)
)
begin
declare v_id_publicacion bigint;
   insert into tbl_publicacion
               (
               id_subcategoria,
               id_usuario,
               titulo,
               fecha_publicacion,
               fecha_vencimiento,
               activa,
               fecha_hora
               )
        values (
               p_id_subcategoria,
               p_id_usuario,
               p_titulo,
               current_date(),
               adddate(current_date(), interval p_dias_publicacion day),
               1, 
               current_timestamp()
               );   
               
   set v_id_publicacion = LAST_INSERT_ID();
   insert into tbl_articulo
               (
                id_publicacion,
                id_estado_articulo,
                descripcion,
                precio,
                existencia
               )
        values (
                v_id_publicacion,
                p_id_estado_articulo,
                p_descripcion,
                0,
                1
                );
                
   if (p_foto_1 <>'') then              
	   insert into tbl_fotos
		       (
		       id_publicacion,
		       foto,
		       tipo,
		       tamano  
		       )
		values (
			v_id_publicacion,
			p_foto_1,
			p_tipo_1,
			p_tamano_1
			);
    end if;			
   IF (p_foto_2 <>'') THEN              
	   INSERT INTO tbl_fotos
		       (
		       id_publicacion,
		       foto,
		       tipo,
		       tamano  
		       )
		VALUES (
			v_id_publicacion,
			p_foto_2,
			p_tipo_2,
			p_tamano_2
			);
    END IF;			
   IF (p_foto_3 <>'') THEN              
	   INSERT INTO tbl_fotos
		       (
		       id_publicacion,
		       foto,
		       tipo,
		       tamano  
		       )
		VALUES (
			v_id_publicacion,
			p_foto_3,
			p_tipo_3,
			p_tamano_3
			);
    END IF;			
                
   set r_mensaje = 'PublicaciÃ³n realizada satisfactoriamente';  
   
   select r_mensaje;              
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_registrar_respuesta` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_registrar_respuesta` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_respuesta`(
   in p_id_pregunta bigint,
   in p_respuesta varchar(1000),
   out r_mensaje varchar(100)  
)
begin
   update tbl_preguntas 
      set respuesta = p_respuesta 
    where id_pregunta = p_id_pregunta;
    
    set r_mensaje = 'Respuesta enviada';
    
    select r_mensaje;  
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_registrar_usuarios` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_registrar_usuarios` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_registrar_usuarios`(
        IN p_login CHAR(20),
        IN p_pass CHAR(20),
        IN p_nombre CHAR(60),
        IN p_correo CHAR(30),
        IN p_telefono CHAR(50),
        IN p_direccion CHAR(255),
        IN p_fecha_nacimiento DATE,
        in p_pregunta char(100),
        in p_respuesta char(100),
        IN p_id_estado INTEGER,
        out r_mensaje varchar(50)
        
    )
BEGIN
   if not (exists(select login 
                    from tbl_usuario  
                   where login = p_login )) then
                    
		INSERT INTO tbl_usuario
						(
						login,
						pass,
						nombre,
						correo,
						telefono,
						direccion,
						fecha_nacimiento,
						fecha_registro,
						pregunta,
						respuesta,
						id_estado,
			  		   activo  
			  	      )
			  VALUES (
						p_login,
						md5(p_pass),
						p_nombre,
						p_correo,
						p_telefono,
						p_direccion,
						p_fecha_nacimiento,
						CURRENT_DATE(),
						p_pregunta,
						p_respuesta, 
						p_id_estado,
						1
						);
					
		     SET r_mensaje = 'Registro Ingresado satisfactoriamente';                         
        end if;                   
   
   select r_mensaje; 
END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_ultimas_publicaciones` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_ultimas_publicaciones` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_ultimas_publicaciones`()
begin
   select a.id_publicacion,
          a.titulo,
          (select b.id_fotos from tbl_fotos b where b.id_publicacion = a.id_publicacion limit 1) as  id_fotos
     from tbl_publicacion a
     order by a.fecha_publicacion desc  
    limit 0, 9;    
          
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_usuarios` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_usuarios` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuarios`()
begin
   select * from tbl_usuarios;
end */$$
DELIMITER ;

/* Procedure structure for procedure `sp_verificar_login` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_verificar_login` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_verificar_login`(
   IN p_login CHAR(20), 
   OUT r_existe BOOL
)
BEGIN
declare v_contador integer;
   
   SELECT count(*) 
    into v_contador
     FROM tbl_usuario 
    WHERE login = p_login;
   
   if (v_contador > 0) then
      set r_existe = true;
   else
      set r_existe = false;
   end if;    
            
   SELECT r_existe;             
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
