<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<?php
  require_once('includes/clase_usuario.php'); 
 

  $txtLogin = "";
  $txtPassword="";
   
  if (isset($_POST['txtLogin']))
    {
	  $usuario = usuario::usuarioSesion($_POST['txtLogin'], $_POST['txtPassword']);
	  if ($usuario)
	    {   
		     if (isset($_SESSION['id_usuario']))
			 {
			  session_start();
              $_SESSION = array();
              session_destroy();
			 }
			  
			
		   session_start();
		   $_SESSION['id_usuario']  = $usuario['id_usuario'];
           $_SESSION['login'] = trim($usuario['login']);
		   $_SESSION['pagina_usuario']  = "frmCuenta.php";
		   $_SESSION['logout'] = "<a class='hipervinculo' href='logout.php'>".$_SESSION['login']." (Salir)</a>";
			
		   //header('Location:'.$_SESSION['url_anterior']);
			header('Location:index.php');
							
		}
	  else
	     {
	     echo "<script>alert('Login o Contraseña invalida!');
		       window.top.location = 'login.php';
			   </script>";	
		  }
	} 
?>


</body>
</html>