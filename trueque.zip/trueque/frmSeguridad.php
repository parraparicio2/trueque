<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript">
   gradiente('cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario1', '8080FF', '4D51F2', 'vertical', '', '' );
	gradiente('separador_menu_usuario2', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario3', '8080FF', '4D51F2', 'horizontal', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
   
$(document).ready(function(){
enviarFormulario('#cmdGuardar', 'usuarioSeguridad.php', '#frmUsuarios', 'validarPagina()');
$('#txtPasswordActual').focusout( function(){
    
    if($('#txtPasswordActual').val()!= ""){
        
        $.ajax({
            type: "POST",
            url: "usuarioBuscarPassword.php",
            data: "txtPasswordActual="+$('#txtPasswordActual').val(),
            beforeSend: function(){
              $('#msgUsuario').html('verificando');
            },
            success: function( respuesta ){
              if(respuesta == false)
              {
                $('#msgUsuario').html("Contrase&ntilde;a Inv&aacute;lida!");
                document.frmUsuarios.txtValido.value = 0;
              }  
              else
              {
                $('#msgUsuario').html("Contrase&ntilde;a V&aacute;lida!");
                document.frmUsuarios.txtValido.value = 1;
              }  
            }
            
        }); 
    }
});   

});

</script>


<title>Datos Personales</title>
</head>

<body>
<?php 
require_once("includes/funciones.php");
   iniciarSesion();
?>
<div id="contenedor">
	<div id="main">
           <div id="contenedor_formulario" style="padding-top:25px;">
              <div id="div_formulario" class="formulario">
                <form id="frmUsuarios" name="frmUsuarios" method="post" action="usuarioSeguridad.php">
                         <div id="header_formulario">    
                         </div><!--cabecera-->
                         
                         <div class="tabla">
               
                            <div class="fila" style="height:50px">
                              <div class="columna_izquierda">Contrase&ntilde;a Actual</div>
                              <div class="columna_izquierda" style="width:150px;"><input name="txtPasswordActual" class ="campo campo_corto" id="txtPasswordActual"  maxlength="16" lang="el login"   /></div>
                              <div class="columna_derecha" style="width:150px;"><span id="msgUsuario"> </span></div>
                            </div> <!--fila-->   
                            
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Contrase&ntilde;a</div>
                               <div class="columna_derecha"><input class ="campo" style=" width:150px " type="password" name="txtPassword" id="txtPassword" maxlength="16" lang ="la contraseña"/></div>
                            </div> <!--fila-->   
                            
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Repita la Contrase&ntilde;a</div>
                               <div class="columna_derecha"><input class ="campo" style=" width:150px " type="password" name="txtRepita" id="txtRepita" maxlength="16" lang= "repetir la contraseña"/></div>

                            </div> <!--fila-->   
              
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Pregunta de Seguridad</div>
                               <div class="columna_derecha"><input class ="campo campo_largo" type="text" name="txtPregunta" id="txtPregunta" maxlength="100" lang= "la Pregunta de Seguridad"/></div>
                            </div> <!--fila-->   

                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Respuesta</div>
                               <div class="columna_derecha"><input class ="campo campo_largo" type="text" name="txtRespuesta" id="txtRespuesta" maxlength="100" lang= "la Respuesta"/></div>
                            </div> <!--fila-->   

							<div id = "respuesta">
                            </div>
               
                         </div> <!--tabla-->
                        <div class ="botones_formulario"> 
                           <input class = "boton_comando" id ="cmdGuardar" name="cmdGuardar" type="button" value="Guardar" />
                           
                        </div>
                   <input type="hidden" name="txtValido" id="txtValido" >
                   <input type="hidden" name="id_usuario" id="id_usuario" value ="<?php echo $_SESSION['id_usuario'] ?>">
                  </form>
                  </div><!--div_formulario-->   
                  
           </div><!--contenedor_formulario-->
	</div><!--main-->
</div><!--contenedor-->
<script type="text/javascript">

function validarPagina()
{
  if (document.frmUsuarios.txtValido.value == 0)
     {
        alert('La contraseña que ingreso no es válida');
        return false;
     }
    
  if (validarDatos(document.frmUsuarios,'') )
     return false;
	 
 	 
	  
  if (document.frmUsuarios.txtPassword.value != document.frmUsuarios.txtRepita.value)
     {
       alert('Las contraseñas ingresadas deben ser iguales.');
       document.frmUsuarios.txtPassword.focus();
       return false;    
     }
 return true;


   
}


</script>
</body>
</html>
