<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es-es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript">
   gradiente('botones_cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
   //f_verificarLogin('txtLogin');
$(document).ready(function(){
$('#txtLogin').focusout( function(){
    if($('#txtLogin').val()!= ""){
        
        $.ajax({
            type: "POST",
            url: "usuarioVerificar.php",
            data: "txtLogin="+$('#txtLogin').val(),
            beforeSend: function(){
              $('#msgUsuario').html('verificando');
            },
            success: function( respuesta ){
              if(respuesta == true)
              {
                $('#msgUsuario').html("No Disponible");
                document.frmUsuarios.txtDisponible.value = 0;
              }  
              else
              {
                $('#msgUsuario').html("Disponible");
                document.frmUsuarios.txtDisponible.value = 1;
              }  
            }
            
        }); 
    }
});   

});
</script>
<?php 
   require_once("includes/clase_usuario.php");
	
?>
<title>Registro de Usuarios</title>
</head>

<body> 

   <div id="cabecera_logo">
      <div id ="logo"> 
      </div><!--logo--> 
   </div>
   <div id ="botones_cabecera" class ="botones_cabecera" >
      <div class = "div_boton" style=" border-right:0px" > <a class="enlaceboton" href="">Ayuda</a> </div>
      <!--div class = "div_boton" > <a class="enlaceboton" href="">Mi Cuenta</a> </div-->
      <div class = "div_boton" > <a class="enlaceboton" href="index.php">Inicio</a> </div>
      <!--/div--> 
   </div><!--botones_cabecera-->

<div id="contenedor_formulario">
     <div id="main_formulario">
     <div id="div_formulario" class="formulario" style="float:left; margin-top:20px">
       <form id="frmUsuarios" name="frmUsuarios" method="post" action = "usuarioRegistrar.php" >
                <div id="header_formulario">    
                </div><!--cabecera-->
                
                <div class="tabla">
      
                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Login</div>
                      <div class="columna_izquierda" style="width:150px;"><input name="txtLogin" class ="campo campo_corto" id="txtLogin"  maxlength="16" lang="el login"   /></div>
                      <div class="columna_derecha" style="width:150px;"><span id="msgUsuario"> </span></div>
                      
                   </div> <!--fila-->   
                   
                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Contraseña</div>
                      <div class="columna_derecha"><input class ="campo" style=" width:150px " type="password" name="txtPassword" id="txtPassword" maxlength="16" lang ="la contraseña"/></div>
                   </div> <!--fila-->   
                   
                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Repita la Contraseña</div>
                      <div class="columna_derecha"><input class ="campo" style=" width:150px " type="password" name="txtRepita" id="txtRepita" maxlength="16" lang= "repetir la contraseña"/></div>
                   </div> <!--fila-->   
      
                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Nombre</div>
                      <div class="columna_derecha"><input name="txtNombre" type="text" class ="campo campo_largo" id="txtNombre" lang= "el nombre " maxlength="60"/></div>
                   </div> <!--fila-->   
      
                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Correo Eléctronico</div>
                      <div class="columna_derecha"><input name="txtCorreo" type="text" class ="campo campo_mediano" id="txtCorreo" maxlength="30" lang = "el correo"/> </div>
                   </div> <!--fila-->   
      
                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Fecha de Nacimiento</div>
                      <div class="columna_derecha">
                        <input name="txtFechaNacimiento" type="text" class ="campo campo_fecha" id="txtFechaNacimiento" value="" maxlength="10" lang = "Fecha de Nacimiento"/>
                         <img src="images/calendar.gif" alt="" width="16" height="16"  id = "img_calendario"/> DD/MM/AAAA
                      </div><!--columna_derecha-->
                   </div> <!--fila-->   
                   
                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Teléfono</div>
                      <div class="columna_derecha"><input name="txtTelefono" type="text" class ="campo campo_largo" id="txtTelefono" maxlength="50" lang = "el Teléfono"/></div>
                   </div> <!--fila-->   
                   
                <div class="fila" style="height:110px" >
                      <div class="columna_izquierda" style="height:80px">Dirección</div>
                      <div class="columna_derecha">
                         <textarea class="campo" name="txtDireccion" id="txtDireccion" cols="35" rows="5" lang = "la Dirección"></textarea>
                      </div>
                   </div> <!--fila-->   
      
                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Pregunta de Seguridad</div>
                      <div class="columna_derecha"><input name="txtPregunta" type="text" class ="campo campo_largo" id="txtPregunta" maxlength="30" lang = "la Pregunta de Seguridad" /> </div>
                   </div> <!--fila-->   

                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Respuesta</div>
                      <div class="columna_derecha"><input name="txtRespuesta" type="text" class ="campo campo_largo" id="txtRespuesta" maxlength="30" lang = "la Respuesta" /> </div>
                   </div> <!--fila-->   

                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">Estado</div>
                      <div class="columna_derecha">
                         <select class = "campo" style=" width:150px " name="cbEstado" id="cbEstado" >
                            <?php 
                               $consulta = new usuario();
                               $result = $consulta->listar_estados();
                               while ($campo = mysqli_fetch_array($result, MYSQLI_ASSOC))
                                 {
									 ?>
									    <option value='<?php echo $campo['id_estado'];?>'><?php echo $campo['nombre'];?></option>
                            <?php    
                                 }   
                            ?>
                          </select>  
                      </div>
                   </div> <!--fila-->                           
      
                </div> <!--tabla-->
               <div style="padding: 15px; font-size:10px"  > 
                  Al inscribirme, declaro que soy mayor de edad y acepto las Políticas de Privacidad y los Térrminos y Condiciones de tus trueques.
               </div>
               <div class ="botones_formulario"> 
                  <input class = "boton_comando" id ="cmdRegistrar" name="cmdRegistrar" type="button" value="Registrar" onclick="validarPagina()"/>
                  <input class = "boton_comando" id ="cmdCancelar" name="cmdCancelar" type="button" value="Cancelar" onclick= "txtLogin.focus()" />
               </div>
               <input type="hidden" name="txtDisponible" id="txtDisponible" >
         </form>
         </div><!--div_formulario-->   
     </div> <!--main-->
</div> <!--contenedor-->
<!--div id = "desarrollado" > DiseÃ±ado por Carlos Parra</div> <!--footer-->

<script type="text/javascript">

function validarPagina()
{
  if (document.frmUsuarios.txtDisponible.value == 0)
     {
        alert('El login que ingreso ya fue seleccionado. Por favor ingrese otro');
        return false;
     }
    
  if (validarDatos(document.frmUsuarios,'') )
     return false;
	 	 
    if (!validarLogin(document.frmUsuarios.txtLogin.value))
     return false;
  
  if (!validarCorreo(document.frmUsuarios.txtCorreo.value))
     return false;
	 
		 
  if (validarFecha('txtFecha') == false)
      return false;	 
	  
  if (document.frmUsuarios.txtPassword.value != document.frmUsuarios.txtRepita.value)
     {
       alert('Las contraseñas ingresadas deben ser iguales.');
       document.frmUsuarios.txtPassword.focus();
       return false;    
     }
  document.frmUsuarios.submit();
   
}

  Calendar.setup
  (
    {
      inputField     :    "txtFechaNacimiento",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario",
      singleClick    :    true,
      step           :    2  
	                
	}
  );
</script>

</body>
</html>
