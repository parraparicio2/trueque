<?php
   define("SERVIDOR","localhost");
	define("USUARIO","root");
	define("NOMBREBD","bdtrueque");
	define("PASSWORD","");
	define("PRINCIPAL","/trueque/index.php");
	define("LOGIN","/trueque/login.php");
    
////////////configuracion del correo
   define('CORREO_USUARIO', 'tustrueques@gmail.com'); 
   define('CORREO_PASWORD', '16459131'); 
   define('CORREO_NOMBRE', 'Tus Trueques'); 
   define('CORREO_HOST', 'ssl://smtp.gmail.com'); 
   define('CORREO_PUERTO', '465'); 
   define('CORREO_SMTP_SECURE', 'ssl'); 

   ///////////configuracion de paginacion
   define('NUMERO_PAGINAS_USUARIO', '5');     
   define('NUMERO_PAGINAS_PUBLICACION', '10'); 
?>