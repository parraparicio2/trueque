<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!--DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>

<link rel="STYLESHEET" type="text/css" href="./css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/menu_categorias.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/galeria.css"/>
<script type="text/javascript" src="./js/jquery.js"></script>
 <script type="text/javascript" src="./js/jquery.corners.js"></script>
 <script type="text/javascript" src="./js/menu_categorias.js"></script>
 <script type="text/javascript" src="./js/jquery.gradient.js"></script>
 <script type="text/javascript" src="./js/css.js"></script>
<title>Ofertas</title>
</head>
<body>
<div id = "contenedor">
   <div id = "main">
	<?php 
	require_once("includes/clase_oferta.php");
	require_once("includes/funciones.php");
	   escribirCabecera();
	    $id_publicacion = $_GET['id_publicacion'];
		$result = oferta::ofertaMisPublicaciones($id_publicacion);
	?>

   <div id="contenedor_oferta">
        <p class="p_informacion">Busque el articulo que desea intercambiar y haga click en el boton aceptar</p>
         <form id = "frmOferta" name = "frmOferta" method="post" action="ofertaAceptar.php">
             <div id = "tabla" class = "tablacss">
                <?php 
                   while($oferta = mysqli_fetch_array($result, MYSQL_ASSOC) )
                   {			   
                          $id_foto = $oferta['id_fotos'];
						  $boton_aceptar = $oferta['id_oferta'];
                ?> 
                <div id = "fila" class = "fila borde_punteado">
                   <div id = "columna_foto" class = "colcss mis_ofertas mis_ofertas_foto">
                      <a href="publicacion.php?id_publicacion=<?php echo $oferta['id_publicacion_oferta'] ?>"><img src="cargarImagenPublicacion.php?id_foto=<?php echo $id_foto ?> " class = "mis_ofertas_imagen"/></a>
                      
                   </div><!--columna_foto-->
                   <div id = "columna_titulo" class = "colcss mis_ofertas mis_ofertas_titulo"><a class ="hipervinculo titulo_mis_oferta" href="publicacion.php?id_publicacion=<?php echo $oferta['id_publicacion_oferta'] ?>"><?php echo $oferta['titulo'] ?></a><img class="valign"/></div><!--columna_titulo-->
                   <div id = "columna_boton" class = "colcss mis_ofertas mis_ofertas_boton"><input type="button" id ="<?php echo $boton_aceptar ?>" name ="<?php echo $boton_aceptar ?>"  value="Aceptar" class="boton_normal" onClick="aceptarOferta('<?php echo $boton_aceptar ?>')"><img class="valign"/>
                   </div><!--columna_boton-->
                </div><!--fila-->
                <?php
                }
                ?>
             </div><!--tabla-->
             <input type="hidden" id = "id_oferta" name = "id_oferta" >
             
         </form>
      </div><!--contenedor_oferta-->
   </div><!--main-->
</div><!--contenedor-->


<script type="text/javascript">
function aceptarOferta(id_objeto){
var objeto;
	objeto = document.getElementById(id_objeto);
    document.frmOferta.id_oferta.value = objeto.name;
    document.frmOferta.submit();	
}
</script>
</body>
</html>
