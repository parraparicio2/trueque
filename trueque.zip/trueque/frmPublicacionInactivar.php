<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="STYLESHEET" type="text/css" href="./css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/form.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/menu_categorias.css"/>
 <script type="text/javascript" src="./js/jquery.js"></script>
 <script type="text/javascript" src="./js/jquery.corners.js"></script>
 <script type="text/javascript" src="./js/menu_categorias.js"></script>
 <script type="text/javascript" src="./js/jquery.gradient.js"></script>
 <script type="text/javascript" src="./js/css.js"></script>
 <script type="text/javascript" src="./js/jcarousellite_1.0.1c5.js"></script>
 <script type="text/javascript" src="./js/jquery-ui.min.js"></script>
 <script type="text/javascript" src="./js/validar.js"></script>
 <script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript">
<?php 
require_once("includes/funciones.php");
require_once("includes/clase_publicacion.php");
   $id_publicacion = $_GET['id_publicacion'];
   $fotos_publicacion = publicacion::publicacionFotosPorIdPublicacion($id_publicacion);
	$numero_filas = mysqli_num_rows($fotos_publicacion);
	$paginas_fotos = publicacion::publicacionPaginarFotos($numero_filas);
	$id_usuario = "";

?>
   gradiente('botones_cabecera', '8080FF', '4D51F2', 'vertical', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
	menuDesplegable();
	




////////////carrusel de fotos	
$(function() {
	$("#slidebox").jCarouselLite({
		vertical: false,
		hoverPause:true,
		btnPrev: ".previous_foto",
		btnNext: ".next_foto",
		visible: 1,
		start: 0,
		scroll: 1,
		circular: true,
		auto:5000,
		speed:500,				
		btnGo:[<?php echo $paginas_fotos ?> ],
	 

		afterEnd: function(a, to, btnGo) {
				if(btnGo.length <= to){
					to = 0;
				}
				$(".thumbActive").removeClass("thumbActive");
				$(btnGo[to]).addClass("thumbActive");
		    }
	});
});

/////////fin de carrusel de fotos
//////
function enviarPregunta()
{
	 if (trim(document.forms[0].id_usuario.value) == '')
	 {
	   $('#login').dialog('open');
		return false;
    }
	
	if (trim(document.frmDatos.txtPregunta.value) == '')
	  {
		  alert('Debe ingresar una pregunta');
		  return false;
		}   
	return true;
	
}

function inactivar()
{
	if (confirm('¿Esta seguro que desea inactivar la publicación?' ))
	{
		
	   document.frmDatos.submit();
	}
	else
	   return false;   
}

	
</script>
<?php 
	escribirCabeceraSinUsuario();
	if (isset($_SESSION['id_usuario']))
	   $id_usuario = $_SESSION['id_usuario'];
   else 		  
	   $id_usuario = "";

	$_SESSION['pagina_usuario'] ="publicacionBuscarActivas.php";
	 $publicacion = publicacion::publicacionPorId($id_publicacion);
?>

<title>Publicaci&oacute;n</title>
</head>
<body>


<div id="publicacion_categoria">
<?php
   echo "Categoria: ".$publicacion['r_nombre_categoria']."->".$publicacion['r_nombre_subcategoria'];
   
 ?>
     <div id = "publicacion_numero">
        <?php echo "Publicaci&oacute;n #".$publicacion['r_id_publicacion'] ?>
     </div> 
</div><!--publicacion_categoria--> 
<div id="contenedor">
   <div id="main">
   

      <div id="publicacion_izquierda">
         <div id="slidebox">
         <?php
		   if ($numero_filas > 1)
		   { 
           echo "<div class='next_foto'>></div>";
           echo "<div class='previous_foto'><</div>";
		   }
		 ?>
         <div class="thumbs">
         <?php 
			   // asignar la paginacion de las fotos
			   for ($i =1; $i <= $numero_filas; $i++ )
				{
				   if ($i == 1) 
					   echo "<a href='#' onClick='' class='".$i." thumbActive'>".$i."</a>";
					else
					   echo "<a href='#' onClick='' class='".$i."'>".$i."</a>";
				}
			?>						
       
         </div>
            <ul>
               <?php 
					   //cargar las fotos
					   $i = 1;
					   if ($numero_filas > 0)
						  {
							  while ($fotos = mysqli_fetch_array($fotos_publicacion, MYSQL_ASSOC))
							  {
								echo "<li><img src='cargarImagenPublicacion.php?id_foto=". $fotos['id_fotos'] ."' width='90%'  /></li>";
							  }
						  }   
					?>
            </ul>
         </div>
         
      </div><!--publicacion_izquierda--> 
      <div id="publicacion_derecha">

         <div id="publicacion_titulo">
            <?php echo $publicacion['r_titulo'];?>
         </div><!--publicacion_titulo-->
         <div id="publicacion_estado">
            Ubicaci&oacute;n: <?php echo $publicacion['r_nombre_estado'];?>
         </div><!--publicacion_estado-->
         <div id="publicacion_condicion">
            <?php echo "Condici&oacute;n: ".$publicacion['r_descripcion_estado'];?>
         </div><!--publicacion_condicion-->
         <div id="publicacion_usuario">
            <p style="font-size:14px;">Fecha Publicaci&oacute;n</p>
            <?php echo transformarFecha($publicacion['r_fecha_publicacion']);?>
            <p style="font-size:14px;">Fecha Finalizaci&oacute;n</p>
            <?php echo transformarFecha($publicacion['r_fecha_registro']) ?>
            
         </div><!--publicacion_usuario-->
         <div id="publicacion_ofertar">
            <input type="button" id="cmdOferta" name="cmdInactivar" class="boton_normal" value="Inactivar" onclick="inactivar()">
           
         </div>
      </div><!--publicacion_derecha--> 
      <div id="publicacion_cuerpo">
          <fieldset style="border:solid #CCC 1px; text-align:left">
            <legend>Descripci&oacute;n</legend>
            <div id="publicacion_descripcion">
               
                  <?php echo $publicacion['r_descripcion'];?>
               
            </div><!--publicacion_descripcion-->
         </fieldset >
         <form id= "frmDatos" name = "frmDatos" method="post" action="publicacionInactivar.php">
         <input type = "hidden" id="id_usuario" name = "id_usuario" value="<?php echo $id_usuario ?>">
         <input type ="hidden" id="id_publicacion" name = "id_publicacion" value="<?php echo $id_publicacion ?>">
         </form>

      </div><!--publicacion_cuerpo-->   
   </div><!--main-->
</div><!--contedor--> 
</body>
</html>