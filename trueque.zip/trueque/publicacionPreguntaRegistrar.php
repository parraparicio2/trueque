<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin t�tulo</title>
</head>
<?php 
   
   require_once("includes/clase_publicacion.php");
   $pregunta = publicacion::publicacionRegistrarPregunta($_POST['id_publicacion'], $_POST['id_usuario'], $_POST['txtPregunta']); 
	echo "<script>alert('".$pregunta."')</script>";	
	echo "<div class = 'preguntas'><img src='./images/pregunta.png'/>".$_POST['txtPregunta']."</div> ";
?>

<body>
<script> 
   document.frmDatos.txtPregunta.value = ''
	document.getElementById('publicacion_preguntas').innerHTML = document.getElementById('span_respuesta').innerHTML  + document.getElementById('publicacion_preguntas').innerHTML;
	document.getElementById('span_respuesta').innerHTML = ''; 
	document.getElementById('nopreguntas').innerHTML = ''; 
</script>

</body>
</html>