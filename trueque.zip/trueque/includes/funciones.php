<?php
require_once("configuracion/configurar.php");

function ejecutarConsulta($sql)
{
$link = mysqli_connect(SERVIDOR, USUARIO, PASSWORD, NOMBREBD);

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

mysqli_query($link,"SET NAMES 'utf8'");
$result = mysqli_query($link, $sql);
return $result;
/* free result set */
//mysqli_free_result($result);

/* close connection */
//mysqli_close($link);


}

function ejecutarConsultaResultado($sql)
{
  $consulta = mysqli_query($sql);
  $filasAfectadas = mysqli_affected_rows();

  if ($filasAfectadas > 0)
    return true;
  else
    return false;
   
}
/**************funciones de transformacion de fechas*************************************************/

//funcion que tranforma una fecha de yyyy/mm/dd  a dd/mm/yyyy
function transformarFecha($fecha) //este procedimiento es para mostrar la fecha de la Bd en formato 27/11/2004
	{
		
		$ano=substr($fecha, 0,4);  
		$mes=substr($fecha, 5,2);  
		$dia=substr($fecha, 8,2);  
		
		//$fecha=$ano;
		//$fecha=$dia;
		//$fecha=$mes;

		$fecha=$dia."/".$mes."/".$ano;
	return $fecha;
}
	 
//esta que funcion tranforma una fecha de dd/mm/yyyy al formato yyyy/mm/dd
function formatoFecha($fecha)//este procedimiento es para guardar la fecha en la BD 
	{
		$dia=substr($fecha, 0,2);  
		$mes=substr($fecha, 3,2);  
		$ano=substr($fecha, 6,4);  
		$fecha=$ano."/".$mes."/".$dia;
		  return $fecha;
    }
    

function enviarCorreo($destinatario, $desde, $nombre_desde, $subject, $body) { 
require_once("includes/phpmailer/class.phpmailer.php");
  $subject = utf8_decode($subject);
  $sender = CORREO_NOMBRE;
  $host = "ssl://smtp.gmail.com";// "mail.valery.com";
  $mail = new PHPMailer();
  $mail->IsSMTP();                                      // set mailer to use SMTP
  $mail->Host = CORREO_HOST;  // specify main and backup server
  $mail->Port  = 465;
  $mail->SMTPAuth = true;     // turn on SMTP authentication
  $mail->Username = CORREO_USUARIO;  // SMTP username
  $mail->Password = CORREO_PASWORD; // SMTP password
  $mail->From = $desde;
  $mail->FromName = utf8_decode($nombre_desde);
  $mail->AddAddress($destinatario);
  $mail->AddReplyTo(CORREO_USUARIO, "Info");
  $mail->WordWrap = 50;                                 
  $mail->IsHTML(true);                                 
  $mail->Subject = $subject;
  $mail->Body    = $body;
  $mail->AltBody = $body;
  $mail->Send();
        
        
/*        if(!$mail->Send())
          
        {
          die( "{ success: false, errors: { reason:'El Mensaje no pudo ser enviado.' }}");
        }  
        echo "{ success: true}";
*/        
} 

function datosUsuario()
{
   
   session_start();
	
   echo	"<div id='datos_usuario'>";

  if (isset( $_SESSION['id_usuario']))
    {
     echo $_SESSION['logout'];
	  
	}
  else	
  {
	 
    if ($_SERVER['PHP_SELF'] != PRINCIPAL && $_SERVER['PHP_SELF'] != LOGIN)
        header('Location: login.php');
  }

  $direccionCompleta = 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
  //$_SESSION['url_anterior'] =  $direccionCompleta;
  $_SESSION['url_anterior'] =  "<script>window.location</script>";
  
  echo "</div>";

  if (isset( $_SESSION['id_usuario']))
     return true;
  else
     return false;	  
}

function iniciarSesion()
{
	if (!isset( $_SESSION['id_usuario']))
	session_start();

  if (isset( $_SESSION['id_usuario']))
    {
	  $_SESSION['pagina_usuario'] = $_SERVER['PHP_SELF'];
     return true;
    }
  else
     {
	  header("Location: login.php");	  
     return false;	  
	  }
}


function transformarImagen(&$fileName, $tmpName, $fileSize)
{
  $fp = fopen($tmpName, 'r');
  $content = fread($fp, $fileSize);
  $content = addslashes($content);
  fclose($fp);
        
  if(!get_magic_quotes_gpc())
    {
      $fileName = addslashes($fileName);
     }
 return $content;	  
}

function escribirCabecera()
{

	echo "
	<a href='index.php'>
	<div id='cabecera_logo'>
		<div id='logo'>
		</div> 
	</div>
	</a>"; 
	datosUsuario();

echo "
<div id ='botones_cabecera' class ='botones_cabecera' >
        <div class = 'div_boton' >
           <a class='enlaceboton' href='frmPublicar.php'>Publicar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./miCuenta.php'>Mi Cuenta</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./frmRegistrarUsuarios.php'>Registrarse</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./login.php'>Ingresar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./index.php'>Inicio</a>
        </div>
  </div><!--botones_cabecera-->
";
}

function escribirCabeceraSinUsuario()
{
   session_start();
	echo "
	<a href='index.php'>
	<div id='cabecera_logo'>
		<div id='logo'>
		</div> 
	</div>
	</a>"; 
	//datosUsuario();

echo "
<div id ='botones_cabecera' class ='botones_cabecera' >
        <div class = 'div_boton' >
           <a class='enlaceboton' href='frmPublicar.php'>Publicar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./miCuenta.php'>Mi Cuenta</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./frmRegistrarUsuarios.php'>Registrarse</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./login.php'>Ingresar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./index.php'>Inicio</a>
        </div>
  </div><!--botones_cabecera-->

";
}

function escribirCabeceraBusqueda()
{

	echo "
	<a href='index.php'>
	<div id='cabecera_logo'>
		<div id='logo'>
		</div> 
	</div>
	</a>"; 
	
   session_start();
	
   echo	"<div id='datos_usuario'>";

  if (isset( $_SESSION['id_usuario']))
    {
     echo $_SESSION['logout'];
	  
	}
  
  $_SESSION['url_anterior'] =  "";
  
  echo "</div>";
	 
echo "
<div id ='botones_cabecera' class ='botones_cabecera' >
        <div class = 'div_boton' >
           <a class='enlaceboton' href='frmPublicar.php'>Publicar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./miCuenta.php'>Mi Cuenta</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./frmRegistrarUsuarios.php'>Registrarse</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./login.php'>Ingresar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./index.php'>Inicio</a>
        </div>
  </div><!--botones_cabecera-->
";
}


?>      




