<?php
require_once("funciones.php");
class publicacion {

public static function listar_categorias()
{ 
  $sql = "CALL sp_listar_categorias()";
  $result = ejecutarConsulta($sql);
  return $result;
}

public static function listar_subcategorias($id_categorias)
{ 
  $sql = "CALL sp_listar_subcategorias($id_categorias)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  return $result;
}

public static function listar_subcategorias_todas()
{ 
  $sql = "CALL sp_listar_subcategorias_todas()";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  return $result;
}

public static function listar_estado_articulo()
{ 
  $sql = "CALL sp_estado_articulo(NULL)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  return $result;
}

public static function buscar_estado_articulo($id_estado_articulo)
{ 
  $sql = "CALL sp_listar_subcategorias_todas($id_estado_articulo)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  return $result;
}

public static function publicacionRegistrar($id_subcategoria, $id_usuario, $titulo, $fecha_publicacion, $dias_publicacion, $descripcion, $id_estado_articulo, $foto_1, $tipo_1, $tamano_1, $foto_2, $tipo_2, $tamano_2, $foto_3, $tipo_3, $tamano_3)
{ 
  $sql = "CALL sp_registrar_publicacion( $id_subcategoria, $id_usuario, '$titulo', '$fecha_publicacion', $dias_publicacion, '$descripcion',$id_estado_articulo, '$foto_1', '$tipo_1', '$tamano_1', '$foto_2', '$tipo_2', '$tamano_2', '$foto_3', '$tipo_3', '$tamano_3', @r_mensaje)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
  
}

public static function publicacionContar($id_usuario, $activa)
{ 
  $sql = "CALL sp_contar_publicacion_usuario($id_usuario, $activa)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['cantidad'];
}

public static function publicacionUsuarioBuscar($id_usuario, $inicio, $cantidad, $activa)
{ 
  $sql = "CALL sp_publicacion_usuario($id_usuario, $inicio, $cantidad, $activa)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  //$campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
}
public static function publicacionPorId($id_publicacion)
{ 
  $sql = "CALL sp_buscarPublicacionPorId($id_publicacion)";
//  echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo;
}

public static function publicacionFotosPorIdPublicacion($id_publicacion)
{ 
  $sql = "CALL sp_buscar_fotos_publicacion($id_publicacion)";
//  echo $sql;
  $result= ejecutarConsulta($sql);
  //$campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
}

public static function publicacionPaginarFotos($numero_fotos)
{ 
  if ($numero_fotos == 0)
     return "'.1'";
	   
  $cadena = "";
  for ($i=1; $i <= $numero_fotos; $i++ )
    {
		 $cadena = $cadena."'.".$i."',"; 
	 }
	 $longitud = strlen($cadena);
//	 echo $longitud;
	 $cadena = substr($cadena,0, $longitud-1);
  return $cadena;	 
}

function publicacionFotoPorId($id_foto)
{ 
  $sql = "CALL sp_buscar_foto_id($id_foto)";
 // echo $sql;
  
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQL_ASSOC);
  return $campo;
}

public static function publicacionPreguntasPorId($id_publicacion)
{ 
  $sql = "CALL sp_buscar_preguntas($id_publicacion)";
  $result= ejecutarConsulta($sql);
  return $result;
}
public static function publicacionRegistrarPregunta($id_publicacion, $id_usuario, $pregunta)
{
  $sql = "CALL sp_registrar_preguntas($id_publicacion, $id_usuario, '$pregunta', @r_mensaje)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
}

public static function publicacionUltimas()
{
  $sql = "CALL sp_ultimas_publicaciones()";
  //echo $sql;
  $result= ejecutarConsulta($sql);
//  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
}

public static function publicacionPreguntasResponder($id_usuario)
{
  $sql = "CALL sp_preguntas_responder($id_usuario)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
//  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
}
public static function publicacionRespuestaRegistrar($id_pregunta, $respuesta)
{
  $sql = "CALL sp_registrar_respuesta($id_pregunta,'$respuesta',@r_mensaje)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
}

public static function publicacionActivar($id_publicacion, $id_usuario, $activa)
{
  $sql = "CALL sp_activar_publicacion($id_publicacion,'$id_usuario',$activa,@r_mensaje)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
}

public static function publicacionActualizar($id_publicacion, $id_subcategoria, $id_usuario, $titulo, $fecha_publicacion, $dias_publicacion, $descripcion, $id_estado_articulo, $foto_1, $tipo_1, $tamano_1, $foto_2, $tipo_2, $tamano_2, $foto_3, $tipo_3, $tamano_3, $id_foto_1, $id_foto_2, $id_foto_3 )
{ 
  $sql = "CALL sp_actualizar_publicacion($id_publicacion, $id_subcategoria, $id_usuario, '$titulo', '$fecha_publicacion', $dias_publicacion, '$descripcion',$id_estado_articulo, '$foto_1', '$tipo_1', '$tamano_1', '$foto_2', '$tipo_2', '$tamano_2', '$foto_3', '$tipo_3', '$tamano_3',$id_foto_1, $id_foto_2, $id_foto_3, @r_mensaje)";
 // echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
  
}

public static function publicacionBuscar($titulo, $id_estado, $inicio, $cantidad)
{ 
  $sql = "CALL sp_buscar_publicacion('$titulo', $id_estado, $inicio, $cantidad)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  return $result;
}

public static function publicacionContarPublicacion($titulo, $id_estado)
{ 
  $sql = "CALL sp_contar_publicacion('$titulo', $id_estado)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['cantidad'];
}

public static function publicacionBuscarCategoria($id_categoria,$id_estado, $inicio, $cantidad)
{ 
  $sql = "CALL sp_buscar_publicacion_categoria($id_categoria, $id_estado, $inicio, $cantidad)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  return $result;
}

public static function publicacionContarPublicacionCategoria($id_categoria, $id_estado)
{ 
  $sql = "CALL sp_contar_publicacion_categoria($id_categoria, $id_estado)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['cantidad'];
}


}
?>