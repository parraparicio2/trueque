<?php

/*
C�digo creado por sgq995 para kekomundo, esto no se aprende de la noche a la ma�ana, llevo casi 1 a�o y medio aprendiendo PHP y todav�a aprendo cosas...
Si este c�digo se lleva a otro foro, pido que mantenga mis cr�ditos.
Se puede optimizar el c�digo de salida con funciones que hagan que el HTML sea de una sola linea, o con Gzip.
*/

class template
{
	/* Directorio donde est�n ubicadas las plantillas */
	private $Carpeta = 'templates';
	
	/* Se define $Variables como array para poder obtener y reemplazar correctamente */
	private $Variables = array();
	
	/* Esta funci�n crea nuevas variables que se aplicaran en las plantillas */
	public function NuevaVariable($variable, $valor)
	{
		/* Aqu� se ve por que $Variables debe ser array */
		$this->Variables[$variable] = $valor;
	}
	
	/* Coge el c�digo insertado y reemplaza por un valor en especifico, si ese valor no existe no ocurre nada, y contin�a con las dem�s */
	public function ReemplazarVariables($codigo)
	{
		/* Convierto el array $Variables en una sola variable con su valor "as $variable => $valor" */
		foreach($this->Variables as $variable => $valor)
		{
			/* Aqu� es donde se reemplazan las variables, actualmente las variables tienen el simbolo dolar "$" antes(un ejemplo: "$holamundo" que asumira su respectivo valor dado por la funci�n "NuevaVariable"), se puede cambiar por cualquier otro tipo, tan solo cambiando " '$' . $variable " por el tipo de variable que se desea, ejemplo '{' . $variable . '}', entonces la variable en la plantilla deberia ser "{hola}" */
			$codigo = str_replace('$' . $variable, $valor, $codigo);
		}
		/* Retorna el c�digo con las variables cambiadas por su respectivo valor */
		return $codigo;
	}
	
	/* Una funci�n simple, para no tener que hacer un echo por cada plantilla que se quiera utilizar */
	public function ImprimirCodigo($codigo)
	{
		echo $codigo;
	}
	
	/* La mas importante, aunque necesita varias de las funciones anteriores, como ven tiene 2 variables a insertar que son $plantilla(nombre de la plantilla que se desea insertar) y $tipo(no es necesario, tiene su valor por defecto como vacio "", mas adelante se explica para que funciona) */
	public function IncluirPlantilla($plantilla, $tipo = "")
	{		
		if(empty($tipo))
		{
			/* Si esta vacio "$tipo" */
			/* ob_start() comienza con la captura del c�digo html, js, css, etc... */
			ob_start();
			/* Incluye el archivo .ptll que es la plantilla esta extension se puede cambiar por la que se desee */
			include $this->Carpeta . '/' . $plantilla . '.ptll';
			/* Es necesario incluir la plantilla para obtener sus contenidos con ob_get_contents(), recuerden ob_start() solo inicia, si no se define el ob_get_contents() en una variable no servira */
			$Codigo = ob_get_contents();
			/* Termina la captura del c�digo con ob_end_clean() */
			ob_end_clean();
		}
		else
		{
			/* Si "$tipo" no esta vacio */
			ob_start();
			/* Llegamos a la parte donde se explica "$tipo" :O, la verdad esto solo es para que sea un poco m�s organizado, lo que hace es agregar un seudonombre, ejemplo: "IncluirPlantilla('index', 'page')" y lo que hace es buscar el archivo que sea "page.index.ptll" osea solo agrega el ".", este se puede cambiar por un "_" o alg�n otro caracter que se le pueda poner de nombre a un archivo... recuerden que se puede cambiar la extension... */
			include $this->Carpeta . '/' . $tipo . '.' . $plantilla . '.ptll';
			/* Es necesario incluir la plantilla para obtener sus contenidos con ob_get_contents(), recuerden ob_start() solo inicia, si no se define el ob_get_contents() en una variable no servira */
			$Codigo = ob_get_contents();
			/* Termina la captura del c�digo con ob_end_clean() */
			ob_end_clean();
		}
		/* Aqu� la parte mas sorprendente o.o, bueno comenzamos a reemplazar todas las variables que tenga el archivo */
		$Reemplazo = $this->ReemplazarVariables($Codigo);
		/* Se acuerdan de la funci�n imprimir, el simple "echo", esta imprime en pantalla el c�digo con las variables reemplazadas */
		$Imprimir = $this->ImprimirCodigo($Reemplazo);
		/* Y aqu� la raz�n por la que utilizo la funci�n anterior */
		return $Imprimir;
	}
}

?>