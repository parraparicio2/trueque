<?php 
require_once("funciones.php");
class oferta {

public static function ofertaRegistrar($id_publicacion, $id_publicacion_oferta, $id_usuario)
{ 
  $sql = "CALL sp_registrar_oferta($id_publicacion, $id_publicacion_oferta, $id_usuario)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  //$campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
  
}

public static function ofertaUsuarioBuscar($id_usuario, $inicio, $cantidad)
{ 
  $sql = "CALL sp_buscar_ofertas_usuario($id_usuario, $inicio, $cantidad)";
 // echo $sql;
  $result= ejecutarConsulta($sql);
  //$campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
}


public static function ofertaContar($id_usuario)
{ 
  $sql = "CALL sp_contar_ofertas_usuario($id_usuario)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['cantidad'];
}

public static function ofertaContarPublicacion($id_usuario)
{ 
  $sql = "CALL sp_contar_oferta_publicacion($id_usuario)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['cantidad'];
}

public static function ofertaPublicacionUsuario($id_usuario, $id_publicacion)
{ 
  $sql = "CALL sp_publicacion_usuario_oferta($id_usuario, $id_publicacion)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  //$campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
}

public static function ofertaUsuarioPublicacion($id_usuario, $inicio, $cantidad)
{ 
  $sql = "CALL sp_oferta_usuario($id_usuario, $inicio, $cantidad)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  //$campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
}

public static function ofertaMisPublicaciones($id_publicacion)
{ 
  $sql = "CALL sp_oferta_mi_publicacion($id_publicacion)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  //$campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $result;
}

public static function ofertaAceptar($id_oferta)
{ 
  $sql = "CALL sp_oferta_aceptar($id_oferta, @r_mensaje)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  
  return $campo['r_mensaje'];
}

public static function ofertaDatosIntercambio($id_oferta)
{ 
  $sql = "CALL sp_datos_intercambio($id_oferta)";
  //echo $sql;
  $result= ejecutarConsulta($sql);
  while ($oferta = mysqli_fetch_array($result, MYSQLI_ASSOC))
    {
		$correo_oferta = $oferta['r_correo_oferta'];
		$correo = $oferta['r_correo'];
		//correo publicacion 
		$cuerpo_mensaje= "
		
			<style type='text/css'>
			p{
				
				font-size:14px;
				font-family:'Arial Black', Gadget, sans-serif;
			}
			.columna{ 
			background-color:#B9B9FF;
			border:0px;
			width:100px;
			font-size:16px;
			}
			
			.columna_datos{ 
			background-color:#FFF;
			border:0px;
			width:280px;
			font-size:16px;
			
			}
			table{
				
				border:2px solid #CCC;
				width:420px;
			} 
			</style>		
		<p>Felicidades! has realizado un trueque</p>
		<p>Esta es la informaci&oacute;n de contacto</p>
		<table>
		  <tr>
			<td class ='columna'>Tu Publicacion:</td>
			<td class ='columna_datos'>".$oferta['r_titulo']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Tu Trueque:</td>
			<td class ='columna_datos'>".$oferta['r_titulo_oferta']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Nombre:</td>
			<td class ='columna_datos'>".$oferta['r_nombre']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Correo:</td>
			<td class ='columna_datos'>".$oferta['r_correo']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Telefono:</td>
			<td class ='columna_datos'>".$oferta['r_telefono']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Direccion:</td>
			<td class ='columna_datos'>".$oferta['r_direccion']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Estado:</td>
			<td class ='columna_datos'>".$oferta['r_estado']."</td>
		  </tr>
		</table>
        ";

		$cuerpo_mensaje_oferta = "
		
			<style type='text/css'>
			p{
				
				font-size:14px;
				font-family:'Arial Black', Gadget, sans-serif;
			}
			.columna{ 
			background-color:#B9B9FF;
			border:0px;
			width:100px;
			font-size:16px;
			}
			
			.columna_datos{ 
			background-color:#FFF;
			border:0px;
			width:280px;
			font-size:16px;
			
			}
			table{
				
				border:2px solid #CCC;
				width:420px;
			} 
			</style>		
		<p>Felicidades! has realizado un trueque</p>
		<p>Esta es la informaci&oacute;n de contacto</p>
		<table>
		  <tr>
			<td class ='columna'>Tu Publicacion:</td>
			<td class ='columna_datos'>".$oferta['r_titulo_oferta']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Tu Trueque:</td>
			<td class ='columna_datos'>".$oferta['r_titulo']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Nombre:</td>
			<td class ='columna_datos'>".$oferta['r_nombre_oferta']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Correo:</td>
			<td class ='columna_datos'>".$oferta['r_correo_oferta']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Telefono:</td>
			<td class ='columna_datos'>".$oferta['r_telefono_oferta']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Direccion:</td>
			<td class ='columna_datos'>".$oferta['r_direccion_oferta']."</td>
		  </tr>
		  <tr>
			<td class ='columna'>Estado:</td>
			<td class ='columna_datos'>".$oferta['r_estado_oferta']."</td>
		  </tr>
		</table>
        ";

	}
  
  enviarCorreo($correo, CORREO_USUARIO, CORREO_NOMBRE, 'Felicidades! has realizado un trueque', $cuerpo_mensaje);
  enviarCorreo($correo_oferta, CORREO_USUARIO, CORREO_NOMBRE, 'Felicidades! has realizado un trueque', $cuerpo_mensaje_oferta); 
}





}
?>