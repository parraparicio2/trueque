<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="STYLESHEET" type="text/css" href="./css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/form.css"/>
<link rel="STYLESHEET"  href="./css/jquery-ui.css" >
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript">
   //gradiente('botones_cabecera', '8080FF', '4D51F2', 'vertical', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
	
</script>
<script type="text/javascript">
function buscar(){
	
   if (document.frmBuscar.txtBuscar.value.length == 0)
   {
	   
	  alert('Debe ingresar un texto en la busqueda');  
      return false; 
   }
   //document.getElementById('id_estado').value = document.getElementById('cbEstado').value;
   document.frmBuscar.submit();	  
}

</script>
<title>Tu Trueque</title> 
</head>
<body>


<?php 
require_once("includes/clase_publicacion.php");
require_once("includes/clase_usuario.php");
require_once("includes/funciones.php");
   escribirCabeceraBusqueda();
   
   $txtBuscar = "";
   $id_estado = "";

   if (isset($_POST['txtBuscar']))
      $txtBuscar = $_POST['txtBuscar'];

   if (isset($_POST['cbEstado']))
      $id_estado = $_POST['cbEstado'];
   else
      $id_estado = "-1"; 	  
?>
<div id="separador_publicacion"></div>             
  <form id = "frmBuscar" name = "frmBuscar" action = "buscarPublicacion.php" method="post">
       <div id="contenedor_busqueda">  
                      <div style="width:90%; height:100%; margin: 0 auto;" >
                         <div id="campo_busqueda" class="redondear">
                            <input class="txt_campo_buscar" type="text" name="txtBuscar" id="txtBuscar" value="<?php echo $txtBuscar ?>" /><img class="valign">
                         </div><!--campo busqueda-->
                         <div id="contenedor_boton_busqueda" >
                            <input class="boton_normal" type="button" name="cmdBuscar" id="cmdBuscar" value="Buscar" style="height:40px" onClick="buscar()" />
                         </div>
                      </div>
					  <input type = "hidden" id="cbEstado" name ="cbEstado">
       </div><!--contenedor_busqueda-->
<div id="separador_publicacion"></div>                    
		<div id="contenedor_busqueda_estado">
		   Busqueda por Estado:
			<select class = "campo" style=" width:150px " name="cbEstado" id="cbEstado" onChange="buscar()" >
									<option value='-1'>Todos</option>
									<?php 
									
									   $consulta = new usuario();
									   $result = $consulta->listar_estados();
									   while ($campo = mysqli_fetch_array($result, MYSQLI_ASSOC))
										 {
									         if ($id_estado== $campo['id_estado'])
									            echo "<option value='".$campo['id_estado']."' selected='selected'>".$campo['nombre']."</option>";
									         else 
											    echo "<option value='".$campo['id_estado']."'>".$campo['nombre']."</option>";
										 }   
									?>
								  </select>  
		</div>
  </form>        

<?php

if(empty($_POST['page']))
   $page = 0;
else
   $page = $_POST['page'];

if($page)
{
//$page = $_POST['page'];
$cur_page = $page;
$page -= 1;
$per_page = NUMERO_PAGINAS_PUBLICACION;
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
$start = $page * $per_page;
$result = publicacion::publicacionBuscar($txtBuscar,$id_estado, $start, NUMERO_PAGINAS_PUBLICACION);
$numero_filas = mysqli_num_rows($result);
//echo $numero_filas;
  if ($numero_filas == 0)
    {
?>
  <div id='datos_publicacion_busqueda' class='tablacss'>
      <div id='fila1' class = 'filascss' >
         <p id="no_resultado"> No se encontraron resultados. </p>
      </div>
  </div>
<?php 		
		//exit;
    }
  else
     {	
      echo "<div id='datos_publicacion_busqueda' class='tablacss'>";
				

$msg = "";
while ($publicacion = mysqli_fetch_array($result, MYSQLI_ASSOC)) 
  {

    $htmlmsg=htmlentities($publicacion['id_publicacion']);
     $id_foto = $publicacion['id_fotos']; 
	       echo "
	         <div id='fila1' class = 'filascss' >
		         <div id='columna_foto' class = 'colcss busqueda_publicacion_foto busqueda_publicacion_propiedades' >";
				    echo "<a href='publicacion.php?id_publicacion=".$publicacion['id_publicacion']."' TARGET='_parent'><img src='cargarImagenPublicacion.php?id_foto=".$id_foto."' class = 'busqueda_publicacion_imagen'/></a>";
			echo "</div><!--columna_foto-->
				<div id='columna_publicacion' class = 'colcss busqueda_publicacion_titulo busqueda_publicacion_foto busqueda_publicacion_propiedades' ><a class = 'hipervinculo busqueda_publicacion_propiedades' href='publicacion.php?id_publicacion=".$publicacion['id_publicacion']."' TARGET='_parent'>".$publicacion['titulo']."</a></div><!--columna_publicacion-->
				<div id='columna_estado' class = 'colcss busqueda_publicacion_estado busqueda_publicacion_propiedades' ><div id='div_estado'>Condici&oacute;n</div><div id='div_estado'>".$publicacion['estado_articulo']."</div></div><!--columna_estado_articulo-->
				<div id='columna_estado' class = 'colcss busqueda_publicacion_estado busqueda_publicacion_propiedades' ><div id='div_estado'>Ubicaci&oacute;n</div><div id='div_estado'>".$publicacion['estado']."</div></div><!--columna_estado_articulo-->

				
				</div><!--fila1-->
				
				";

}
echo "</div>";//datos publicacion


$msg = "<div class='data'><ul>" . $msg . "</ul></div>"; // Content for Data//


/* --------------------------------------------- */
$count = publicacion::publicacionContarPublicacion($txtBuscar, $id_estado);
$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
//$msg .= "<div class='pagination' ><ul style='color:white; background: white'>";
$msg .= "<div class='pagination' style ='width:1200px' ><ul>";

// FOR ENABLING THE FIRST BUTTON
if ($first_btn && $cur_page > 1) {
    $msg .= "<li p='1' class='active'>Primero</li>";
} else if ($first_btn) {
    $msg .= "<li p='1' class='inactive'>Primero</li>";
}

// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;
    $msg .= "<li p='$pre' class='active'>Atrás</li>";
} else if ($previous_btn) {
    $msg .= "<li class='inactive'>Atrás</li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active'>{$i}</li>";
    else
        $msg .= "<li p='$i' class='active'>{$i}</li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='active'>Siguiente</li>";
} else if ($next_btn) {
    $msg .= "<li class='inactive'>Siguiente</li>";
}

// TO ENABLE THE END BUTTON
if ($last_btn && $cur_page < $no_of_paginations) {
    $msg .= "<li p='$no_of_paginations' class='active'>Último</li>";
} else if ($last_btn) {
    $msg .= "<li p='$no_of_paginations' class='inactive'>Último</li>";
}
$goto = "<input type='text' class='goto' size='1' style='margin-top:-1px;margin-left:60px;'/>
         <input type='button' id='go_btn' class='go_button' value='Ir a Página'/>";
$total_string = "<span class='total' a='$no_of_paginations'>Página <b>" . $cur_page . "</b> de <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";
//$msg = $msg . "</ul>" . $goto . $total_string . "</div>";  // Content for pagination
if ($no_of_paginations > 1)
   echo $msg;
}

}
?>

</body>
</html>

