<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript">
   gradiente('botones_cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario1', '8080FF', '4D51F2', 'vertical', '', '' );
	gradiente('separador_menu_usuario2', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario3', '8080FF', '4D51F2', 'horizontal', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
</script>
<title>Documento sin título</title>
</head>

<body>
<?php 
require_once('includes/clase_usuario.php');
require_once('includes/clase_publicacion.php');
  
  escribirCabecera();
  $id_usuario = $_SESSION['id_usuario'];
  $_SESSION['pagina_usuario']="";
?>
<div id="contenedor" style="height:auto">
   <div id="main" style="height:auto">
			   <div id="contenedor_formulario" style="padding-top:25px;">
				  <div id="div_formulario" class="formulario">
					<form id="frmPreguntas" name="frmPreguntas" method="post" action="publicacionRegistrarRespuesta.php">
							 <div id="header_formulario">    
							 </div><!--cabecera-->
							 
 					       <div class="tabla">
                      <?php 
							    $existe = false;
							    $result = publicacion::publicacionPreguntasResponder($id_usuario);
								 if ($result)
								 {
									 while ($pregunta = mysqli_fetch_array($result, MYSQL_ASSOC))
									 {
										 $existe = true;
								?>		
                         <div id = "respuesta">
                         </div>

                              <script type="text/javascript">
                              $(document).ready(function(){
                                enviarFormulario(<?php echo "'#".$pregunta['id_pregunta']."'" ?>, 'publicacionRespuestaRegistrar.php', '#frmPreguntas', 'validarPagina(document.activeElement.name)');
                              });  
										</script>

										<div class="fila" style="height:50px; padding:20px;">
											<p class ="informacion"> Publicaci&oacute;n: <?php echo $pregunta['titulo']?></p> 
                                 <p class ="informacion"> Pregunta: <?php echo $pregunta['pregunta']?></p> 
										</div> <!--fila-->   

                              <div class="fila" style="height:110px;" >
                                 <div class="columna_izquierda" style="height:80px; width:10%; font-size:14px; font-weight:600; padding-left:20px; margin-right:10px;">Respuesta</div>
                                 <div class="columna_derecha">
                                   <textarea class="campo" name="<?php echo "txt".$pregunta['id_pregunta'] ?>" id="<?php echo "txt".$pregunta['id_pregunta'] ?>" cols="55" rows="5" lang = "la Pregunta"></textarea>
                                 </div>
                             </div> <!--fila-->   
                             <div class="fila" style="height:50px; padding:20px; border-bottom:#CCC dashed 1px">
                                 <div class ="botones_formulario"> 
                                    <input class = "boton_comando" id ="<?php echo $pregunta['id_pregunta'] ?>" name="<?php echo $pregunta['id_pregunta'] ?>" type="button" value="Responder" />
                                 </div>
                             </div><!--fila-->    

							<?php	 }
							       if (!$existe)
									 {
							?>
                             <div class="fila" style="height:50px; padding:20px; border-bottom:#CCC dashed 1px">
                                <p style="font-size:14px; font-weight:600; text-align:center">No hay preguntas pendientes para responder</p>
                             </div><!--fila-->    
                             <div class="fila" style="height:50px; padding:20px; border-bottom:#CCC dashed 1px">
                                 <div class ="botones_formulario"> 
                                    <input class = "boton_comando" id ="cmdCuenta" name="cmdCuenta" type="button" value="Mi Cuenta" onclick="window.location = 'miCuenta.php'" />
                                 </div>
                             </div><!--fila-->    
                     
                     <?php 			 
									 }
									 
								 }
							 ?>
							      </div> <!--tabla-->
                            <input id="id_usuario" name = "id_usuario" type = "hidden" value = "<?php echo $id_usuario ?>" >
                            <input id="id_pregunta" name = "id_pregunta" type = "hidden" >
                            <input id="responder" name = "responder" type = "hidden" >
					  </form>
					  </div><!--div_formulario-->   
			   </div><!--contenedor_formulario-->
   </div><!--main--> 
</div><!--contenedor-->
<script type="text/javascript">
   
function validarPagina(objeto)
{
	var pregunta;
	var componente;   
	pregunta = 'txt'+objeto; 
	componente = document.getElementById(pregunta);

	if (trim(componente.value)== '')
	{
		alert('Debe ingresar la respuesta');
		componente.focus();
	   return false;
	}
	else
	   {
		document.getElementById(objeto).disabled = true;		
		componente.disabled = true;	
		document.frmPreguntas.id_pregunta.value = objeto;	
		document.frmPreguntas.responder.value = componente.value;	
	   return true;	
		}
}
</script>
</body>
</html>