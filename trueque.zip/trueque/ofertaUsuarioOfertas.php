<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="STYLESHEET" type="text/css" href="./css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/form.css"/>
<link rel="STYLESHEET"  href="./css/jquery-ui.css" >
<script type="text/javascript" src="./js/jquery.js"></script>


<title>Tu Trueque</title> 
</head>
<body>


<?php
require_once("includes/clase_oferta.php");
require_once("includes/funciones.php");
   iniciarSesion();



if(empty($_POST['page']))
   $page = 0;
else
   $page = $_POST['page'];

if($page)
{
//$page = $_POST['page'];
$cur_page = $page;
$page -= 1;
$per_page = NUMERO_PAGINAS_USUARIO;
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
$start = $page * $per_page;
$result = oferta::ofertaUsuarioPublicacion($_SESSION['id_usuario'], $start, NUMERO_PAGINAS_USUARIO, 1);
$numero_filas = mysqli_num_rows($result);
//echo $numero_filas;
  if ($numero_filas == 0)
    {
?>

			   <div id="contenedor_formulario"  style="padding-top:20px">
				  <div id="div_formulario" class="formulario" style="padding-bottom:10px">
					<form id="frmUsuarios" name="frmUsuarios" method="post" action="frmPublicar.php" target="_top">
							 <div id="header_formulario">    
							 </div><!--cabecera-->
							 
							 <div class="tabla">
								
								<div class="fila" style="height:50px; padding:20px;">
								   <p class ="informacion">No tienes ofertas activas.</p>
                                   
								 </div> <!--fila-->   
								   
                       
								<div class ="botones_formulario"> 
								   <input class = "boton_comando" id ="cmdPublicar" name="cmdPublicar" type="submit" value="Publicar" />
								</div>
							 </div> <!--tabla-->
                            <input id="id_usuario" name = "id_usuario" type = "hidden" value = "<?php echo $_SESSION['id_usuario'] ?>"  >
					  </form>
					  </div><!--div_formulario-->   
			   </div><!--contenedor_formulario-->

<?php 		
		exit;
    }
  else
     {	
      echo "<div id='datos_publicacion_busqueda' class='tablacss'>
					<div id='titulo' class = 'filascss' >
						<div id='col_titulo1' class = 'col_titulocss col_foto col_titulo_publicacion' >Foto</div><!--col_titulo1-->
						<div id='col_titulo2' class = 'col_titulocss col_publicacion col_titulo_publicacion' >Publicaci&oacute;n</div><!--col_titulo2-->
						<div id='col_titulo3' class = 'col_titulocss col_oferta col_titulo_publicacion' >Ofertas</div><!--col_titulo3-->
						<div id='col_titulo4' class = 'col_titulocss col_finaliza col_titulo_publicacion' >Finaliza</div><!--col_titulo4-->
						<div id='col_titulo5' class = 'col_titulocss col_oferta_detalles col_titulo_publicacion' >Detalles</div><!--col_titulo5-->
						
 		    </div>";	


$msg = "";
while ($publicacion = mysqli_fetch_array($result, MYSQLI_ASSOC)) 
  {
    $htmlmsg=htmlentities($publicacion['id_publicacion']);
	 if ($publicacion['id_fotos'] == NULL)
	   $id_foto = -1;
	 else
	    $id_foto = $publicacion['id_fotos'];
	
	$dias = $publicacion['dias'];	
	if ($dias < 0)
	   $dias = 0;	
		 	
	 //$msg .= "<li><b>" . $row['dias'] . "</b> " . $htmlmsg . "</li>";
	       echo "
	         <div id='fila1' class = 'filascss' >
		         <div id='columna_foto' class = 'colcss col_foto col_propiedades_publicacion' >";

				    echo "<a class = 'hipervinculo' href='publicacion.php?id_publicacion=".$publicacion['id_publicacion']."' TARGET='_parent'><img src='cargarImagenPublicacion.php?id_foto=".$id_foto."' class ='col_imagen'/></a>";
					  	  
						
			echo "</div><!--columna_foto-->
				<div id='columna_publicacion' class = 'colcss col_publicacion col_propiedades_publicacion' ><a class = 'hipervinculo' href='publicacion.php?id_publicacion=".$publicacion['id_publicacion']."' TARGET='_parent'>".$publicacion['titulo']."</a><img class='valign'></div>
				<div id='columna_oferta' class = 'colcss col_oferta col_propiedades_publicacion' >".$publicacion['cantidad_ofertas']."<img class='valign'></div>				
				<div id='columna_cantidad' class = 'colcss col_finaliza col_propiedades_publicacion' >".$dias."<img class='valign'></div>
				<div id='columna_oferta_detalles' class = 'colcss col_oferta_detalles col_propiedades_publicacion' ><a href = 'ofertaPublicacion.php?id_publicacion=".$publicacion['id_publicacion']."' target = '_top' >Ver Ofertas</a><img class='valign'></div>
			</div><!--fila1-->";

}
echo "</div>";//datos publicacion

$msg = "<div class='data'><ul>" . $msg . "</ul></div>"; // Content for Data//


/* --------------------------------------------- */
$count = oferta::ofertaContarPublicacion($_SESSION['id_usuario'], 1);
$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */
//$msg .= "<div class='pagination' ><ul style='color:white; background: white'>";
$msg .= "<div class='pagination' ><ul>";

// FOR ENABLING THE FIRST BUTTON
if ($first_btn && $cur_page > 1) {
    $msg .= "<li p='1' class='active'>Primero</li>";
} else if ($first_btn) {
    $msg .= "<li p='1' class='inactive'>Primero</li>";
}

// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;
    $msg .= "<li p='$pre' class='active'>Atrás</li>";
} else if ($previous_btn) {
    $msg .= "<li class='inactive'>Atrás</li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#006699;' class='active'>{$i}</li>";
    else
        $msg .= "<li p='$i' class='active'>{$i}</li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='active'>Siguiente</li>";
} else if ($next_btn) {
    $msg .= "<li class='inactive'>Siguiente</li>";
}

// TO ENABLE THE END BUTTON
if ($last_btn && $cur_page < $no_of_paginations) {
    $msg .= "<li p='$no_of_paginations' class='active'>Último</li>";
} else if ($last_btn) {
    $msg .= "<li p='$no_of_paginations' class='inactive'>Último</li>";
}
$goto = "<input type='text' class='goto' size='1' style='margin-top:-1px;margin-left:60px;'/>
         <input type='button' id='go_btn' class='go_button' value='Ir a Página'/>";
$total_string = "<span class='total' a='$no_of_paginations'>Página <b>" . $cur_page . "</b> de <b>$no_of_paginations</b></span>";
$msg = $msg . "</ul></div>";
//$msg = $msg . "</ul>" . $goto . $total_string . "</div>";  // Content for pagination
if ($no_of_paginations > 1)
   echo $msg;
}

}
?>


</body>
</html>

