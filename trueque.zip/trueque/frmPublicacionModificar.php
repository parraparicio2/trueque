<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php 
require_once("includes/funciones.php");
require_once("includes/clase_publicacion.php");
   escribirCabecera();
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="STYLESHEET" type="text/css" href="./css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/menu_categorias.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/formwizard.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/form.css"/>
<link rel="STYLESHEET"  href="./css/jquery-ui.css" >
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/menu_categorias.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<!--script type="text/javascript" src="./js/formToWizard.js"></script-->
<script type="text/javascript" src="./js/formwizard.js"></script>
<script type="text/javascript" src="./js/nicEdit.js"></script>
<script type="text/javascript" src="./js/jquery-ui.min.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>


<script type="text/javascript">

<?php 
require_once("includes/funciones.php");
require_once("includes/clase_publicacion.php");
   $id_publicacion = $_GET['id_publicacion'];
   $fotos_publicacion = publicacion::publicacionFotosPorIdPublicacion($id_publicacion);
   $numero_filas = mysqli_num_rows($fotos_publicacion);
   $paginas_fotos = publicacion::publicacionPaginarFotos($numero_filas);
   $id_usuario = $_SESSION['id_usuario'];

?>

var arregloCategoriaFilas = new Array();
var arregloSubcategoriaFilas = new Array();

   gradiente('botones_cabecera', '8080FF', '4D51F2', 'vertical', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear
	menuDesplegable();
	//llamada al niceeditor
	bkLib.onDomLoaded(function() { new nicEditor().panelInstance('txtDescripcion'); });

$(document).ready(function(){
$("#tabs").tabs();

var myform=new formtowizard({
  formid: 'frmPublicar',
  persistsection: false,
  validate: ['id_subcategoria','txtTitulo', 'cboDias', 'cboDias'],

  revealfx: ['slide', 500] //<--no comma after last setting
 })
 
 $('#imagen1 > img').fadeOut(function(){

	var objImagePreloader = new Image();

	objImagePreloader.onload = function() {

                $('#image1 > img')

                    .removeAttr('src')

                    .attr('src','images/no_disponible.jpeg')

                    .fadeIn();

	}

	objImagePreloader.src = 'images/bigLoader.gif';

});


});//document ready



function cargarSubcategorias(valor, nombreLista)
{

  var lista = document.getElementById(nombreLista);
  vaciarCombo(lista.name);
   for(i=1; i < arregloSubcategoriaFilas.length; i++)
	  {

	     if (arregloSubcategoriaFilas[i][0] == valor )
		  {
		     llenarCombo(lista.name, arregloSubcategoriaFilas[i][2], arregloSubcategoriaFilas[i][1]);
		  }
	  }

  // lista.selectedIndex = 0;
  document.frmPublicar.id_subcategoria.value = '';
}

function buscarCategorias(categoria)
{
var cadena = document.frmPublicar.txtBuscarCategorias.value;
var patron = eval('/'+ cadena +'/i');
var pos;
 vaciarCombo('txtBuscarListaCategoria');
 vaciarCombo('txtBuscarListaSubcategoria');
 for(i=1; i < arregloCategoriaFilas.length; i++)
 {
     cadena = arregloCategoriaFilas[i][1];
	 pos = cadena.search(patron);
	 if (pos >= 0)
	    llenarCombo('txtBuscarListaCategoria', arregloCategoriaFilas[i][1], arregloCategoriaFilas[i][0]);
 }
}

function limpiarCategorias()
{
	document.frmPublicar.txtBuscarCategorias.value = '';
	vaciarCombo('txtBuscarListaCategoria');
	vaciarCombo('txtBuscarListaSubcategoria');
}

function seleccionarSubcategoria(nombreLista)
{
var lista = document.getElementById(nombreLista);
	document.frmPublicar.id_subcategoria.value = lista.value;
}

function cargarImagen(objetoImagen, objetoFile)
{ var imagen = document.getElementById(objetoImagen);
  var archivo = document.getElementById(objetoFile);
   alert(imagen.src);
  imagen.src = 'file:///'+archivo.value;
     alert(imagen.src);
}
/**********cargar imagenes*******************/
	function setpreview(objeto)
	{
	  if (objeto.name == 'archivo1')
	     document.frmPublicar.id_foto_1.value = 0;
      else 	if (objeto.name == 'archivo2')
	     document.frmPublicar.id_foto_2.value = 0;
      else 	if (objeto.name == 'archivo3')
	     document.frmPublicar.id_foto_3.value = 0;
		      	
	  document.frmPublicar.target='null';
	  document.frmPublicar.action='subirImagen.php';
	  document.frmPublicar.submit();
	}
/**********cargar imagenes*******************/

function guardarPublicacion(){
var seleccionado = false; 
   if (trim(nicEditors.findEditor('txtDescripcion').getContent()) == '<br>')
	{
		alert('Debe ingresar la Descripción');
		return false;
	} 
   for ( var i = 0; i < document.frmPublicar.optCondicion.length; i++ )
   {
			if (document.frmPublicar.optCondicion[i].checked)
			{
				seleccionado = true;
				break;
			}
	}

		if (seleccionado == false )
		{
			alert('Debe ingresar la condición');
			return false;
		} 

   //document.frmPublicar.Descripcion.value = nicEditors.findEditor('txtDescripcion').getContent();

	nicEditors.findEditor('txtDescripcion').saveContent();//salva el contenido del text area como html;
	document.frmPublicar.target='_self';
	document.frmPublicar.action = 'publicacionActualizar.php';
	document.frmPublicar.submit();
}

</script>
<?php 
	 $publicacion = publicacion::publicacionPorId($id_publicacion);
	 $txtTitulo = $publicacion['r_titulo'];
	 $txtDias = $publicacion['r_dias'];
	 $txtDescripcion = $publicacion['r_descripcion'];
	 $id_categoria = $publicacion['r_id_categoria']; 
	 $id_subcategoria = $publicacion['r_id_subcategoria'];
	 $id_foto_1 = 0;
	 $id_foto_2 = 0;
	 $id_foto_3 = 0;
	
	 
?>

<title>Tu Trueque</title>
</head>
<body>

<div id="contenedor">
   <div id="main">
     <div id="datos_publicacion">
        <form enctype="multipart/form-data" name = "frmPublicar" class="formulario_publicacion" id = "frmPublicar" action = "publicacionRegistrar.php"  method="post">
           <fieldset class="sectionwrap" />
              <legend>Seleccione la categor&iacute;a</legend>
              <input type = "hidden" id = "id_subcategoria" name = "id_subcategoria" lang = "Subcategoria"  />

              <div id = "div_categoria">
                  <div id="tabs" style="width:675px; height:98%;">
                      <ul>
                          <li><a href="#Tab1" onclick="limpiarCategorias()"><span>Todas las Categorias</span></a></li>
                          <li><a href="#Tab2"><span>Buscar Categoria</span></a></li>

                      </ul>
                      <div id="Tab1" style="height:300px"  >
                         <div id ="div_opcion_categoria" style="float:left">
                             <select name="txtListaCategoria" id="txtListaCategoria" class = "lista_categorias" multiple="multiple" onchange="cargarSubcategorias(frmPublicar.txtListaCategoria.value, 'txtListaSubcategoria');"/>
                             </select>
								<?php
										   //llenar el arreglo y la lista de las categorias
								   $i = 1;
                           $result = publicacion::listar_categorias();
                           if ($result)
									   {
   									echo "
										<script>
										   vaciarCombo('txtListaCategoria');
										</script>";

										while ($categoria = mysqli_fetch_array($result, MYSQLI_ASSOC) )
                                {
  										   echo "<script>";
											echo "var combo = document.getElementById('txtListaCategoria') ;
											 		 if (combo != null)
													   {
											          var idxElemento = combo.options.length;
														 combo.options[idxElemento] = new Option();
														 combo.options[idxElemento].text = '".$categoria['nombre']."';
														 combo.options[idxElemento].value = ".$categoria['id_categoria'].";
									                var arregloCategoriaColumnas = new Array(2);
           									       arregloCategoriaColumnas[0] = ".$categoria['id_categoria'].";
				          					       arregloCategoriaColumnas[1] = '".$categoria['nombre']."';
							          		       arregloCategoriaFilas[".$i."] = arregloCategoriaColumnas;
                               				}
											 </script>";
									       $i++;
                                }
                              }

										//llenar el arreglo las subcategorias
  								      $i= 1;
                              $result = publicacion::listar_subcategorias_todas();
                              if ($result)
								      {
                               while ($subcategoria = mysqli_fetch_array($result, MYSQLI_ASSOC) )
                               {

  										   echo "<script>
									                var arregloSubcategoriaColumnas = new Array(3);
           									       arregloSubcategoriaColumnas[0] = ".$subcategoria['id_categoria'].";
				          					       arregloSubcategoriaColumnas[1] = '".$subcategoria['id_subcategoria']."';
														 arregloSubcategoriaColumnas[2] = '".$subcategoria['nombre']."';
							          		       arregloSubcategoriaFilas[".$i."] = arregloSubcategoriaColumnas;

											 </script>";
									  	   $i++;
                                }
                               }
								?>



                         </div><!--div_opcion_categoria-->

                         <div id ="div_opcion_categoria" style="float:left">
                             <select name="txtListaSubcategoria" id="txtListaSubcategoria" class = "lista_categorias" multiple="multiple" onchange="seleccionarSubcategoria('txtListaSubcategoria')" >
                             </select>
                         </div><!--div_opcion_categoria-->

                      </div><!--Tab1-->
                      <div id="Tab2"style="height:300px">
                         <div id="div_buscar_categoria" style="padding:10px 10px 10px 0px; text-align:left" >
                            <input type ="text" id="txtBuscarCategorias" name = "txtBuscarCategorias" style="width:290px; font-size:16px" >
                            <input type ="button" id="cmdBuscar" name = "cmdBuscar" value="Buscar" class="boton_normal" onClick= " buscarCategorias('')">
                         </div>
                         <div id ="div_opcion2_categoria" style="float:left">
                             <select name="txtBuscarListaCategoria" id="txtBuscarListaCategoria" class = "lista_categorias2" multiple="multiple" onchange="cargarSubcategorias(frmPublicar.txtBuscarListaCategoria.value, 'txtBuscarListaSubcategoria');" >
                             </select>
                         </div><!--div_opcion2_categoria-->
                         <div id ="div_opcion2_subcategoria" style="float:left">
                             <select name="txtBuscarListaSubcategoria" id="txtBuscarListaSubcategoria" class = "lista_categorias2" multiple="multiple" onchange="seleccionarSubcategoria('txtBuscarListaSubcategoria')" >
                             </select>
                         </div><!--div_opcion2_subcategoria-->
                      </div><!--Tab2-->
                  </div><!--Tabs-->
              </div><!--div categoria-->
           </fieldset>

           <fieldset class="sectionwrap" />
              <legend>Informaci&oacute;n de la publicaci&oacute;n</legend>
                <div class="tabla" style="width:700px;">

                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda" >Titulo de la Publicaci&oacute;n</div>
                      <div class="columna_derecha" ><input name="txtTitulo" class ="campo campo_largo" id="txtTitulo"  maxlength="60" lang="T&iacute;tulo" value="<?php echo $txtTitulo?>"/></div>

                   </div> <!--fila-->

                   <div class="fila" style="height:50px">
                      <div class="columna_izquierda">D&iacute;as de Publicaci&oacute;n</div>
                      <div class="columna_derecha">
                        <select name="cboDias" id="cboDias" value ="<?php $txtDias ?>" >
                           <option ="30">30</option>
                           <option ="60">60</option>
                           <option ="90">90</option>
                        </select>

                      </div><!--columna_derecha-->
                   </div> <!--fila-->

                </div> <!--tabla-->
           </fieldset>

           <fieldset class="sectionwrap" />
              <legend>Ingresa las fotos del art&iacute;culo</legend>
              <p style="font-size:14px">El peso de las fotos de ser menor a 2 megas</p>
              
              <div id="fotos_publicacion">
               <?php 
					   //cargar las fotos
					   $i = 1;
					   if ($numero_filas > 0)
						  {
							  while ($fotos = mysqli_fetch_array($fotos_publicacion, MYSQL_ASSOC))
							  {
								echo "<div class='publicacion_foto'><img src='cargarImagenPublicacion.php?id_foto=". $fotos['id_fotos'] ."' alt='No Disponible' border='0' style='width:100%; height:100%'  name ='imagen".$i."' id ='imagen".$i."'/></div>";
	                            if ($i==1)
								   $id_foto_1 =  $fotos['id_fotos'];
								else if ($i==2)
								   $id_foto_2 =  $fotos['id_fotos'];
								else if ($i==3)
								   $id_foto_3 =  $fotos['id_fotos'];
								         
	                            $i++;						  
							  }
						  }   
					
					if ($i < 3)
					{
						for ($j=$i; $j <= 3; $j++)
						{
						   echo "<div class='publicacion_foto'><img src='images/no_disponible.jpeg' alt='No Disponible' border='0' style='width:100%; height:100%' id = 'imagen".$j."' name = 'imagen".$j."'/> </div>";
							
						}
					}
					?>
    		  <input type = "hidden" id = "id_foto_1" name = "id_foto_1" value = "<?php echo $id_foto_1 ?>"/>
              <input type = "hidden" id = "id_foto_2" name = "id_foto_2" value = "<?php echo $id_foto_2 ?>"/>
              <input type = "hidden" id = "id_foto_3" name = "id_foto_3" value = "<?php echo $id_foto_3 ?>"/>
             <div class="elegir_fotos">Examinar...<input class = "subir_archivos" id = "archivo1" name = "archivo1" type="file" value="Elegir" onChange="setpreview(document.frmPublicar.archivo1)"/></div>
                 <div class="elegir_fotos">Examinar...<input class = "subir_archivos" id = "archivo2" name = "archivo2" type="file" value="Elegir" onChange="setpreview(document.frmPublicar.archivo2)"/></div>
                 <div class="elegir_fotos">Examinar...<input class = "subir_archivos" id = "archivo3" name = "archivo3" type="file" value="Elegir" onChange="setpreview(document.frmPublicar.archivo3)"/></div>

              </div>

           </fieldset>

           <fieldset class="sectionwrap" />
              <legend>Descripci&oacute;n del art&iacute;culo</legend>
              <div id="div_descripcion" style="text-align:left" >
                 <textarea name="txtDescripcion" cols="80" rows="15" id = "txtDescripcion" style="height:200px; width:680px" dir="ltr" lang="la Descripci&oacute;n"><?php echo $txtDescripcion?></textarea>
              </div>
              <legend>Condici&oacute;n del art&iacute;culo</legend>
              <div id="div_condicion">
                 <ul style="background-color:#FFF">
                    <?php
					   $result = publicacion::listar_estado_articulo();
					   while ($campo = mysqli_fetch_array($result))
					     {
						   if ($publicacion['r_id_estado_articulo'] == $campo['id_estado_articulo'] )
					         echo "<p><input lang = 'Condici&Oacute;n' name='optCondicion' type='radio' checked value='". $campo['id_estado_articulo']."' />". $campo['descripcion']."</p>";
						   else
						      echo "<p><input lang = 'Condici&Oacute;n' name='optCondicion' type='radio' value='". $campo['id_estado_articulo']."' />". $campo['descripcion']."</p>";   	 
					     }
					?>
                 </ul>
              </div>
              <p style="text-align:center; padding:15px" ><input id="cmdPublicar" type="button" value="Publicar" class ="boton_comando" onclick="guardarPublicacion();"/></p>
           </fieldset>
           <input type="hidden" id = "id_usuario" name = "id_usuario" value = "<?php echo $_SESSION['id_usuario'] ?>">
           <input type="hidden" id = "id_publicacion" name = "id_publicacion" value = "<?php echo $id_publicacion ?>">
            <?php echo "<script>cargarSubcategorias(".$id_categoria.", 'txtListaSubcategoria');
			                    seleccionarCombo('txtListaCategoria', ".$id_categoria.");
								seleccionarCombo('txtListaSubcategoria', ".$id_subcategoria.");
								document.frmPublicar.id_subcategoria.value =".$id_subcategoria."; 
								
			</script>"; ?>
        </form>


        <iframe src="about:blank" name="null" style="display:none">
     </div><!--datos_publicacion-->
   </div><!--main-->
</div><!--contenedor-->

</body>
</html>
