<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>
<?php
  require_once("includes/clase_publicacion.php");
  $mensaje = publicacion::publicacionRespuestaRegistrar($_POST['id_pregunta'],$_POST['responder']);
 // echo $mensaje;							 
  echo "<script>alert('".$mensaje."')</script>";
    //enviarCorreo($_POST['txtCorreo'], CORREO_USUARIO, CORREO_NOMBRE, 'Bienvenido a Tus Trueques', $body);                                          
                                         

?>
<body>

</body>
</html>

