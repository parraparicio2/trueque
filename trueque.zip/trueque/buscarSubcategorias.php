<?php
echo $_GET['id_subcategoria'];

?>