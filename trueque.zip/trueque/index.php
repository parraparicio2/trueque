<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="STYLESHEET" type="text/css" href="./css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/menu_categorias.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/galeria.css"/>
<script type="text/javascript" src="./js/jquery.js"></script>
 <script type="text/javascript" src="./js/jquery.corners.js"></script>
 <script type="text/javascript" src="./js/menu_categorias.js"></script>
 <script type="text/javascript" src="./js/jquery.gradient.js"></script>
 <script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript">
   //gradiente('botones_cabecera', '8080FF', '4D51F2', 'vertical', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
	menuDesplegable();
</script>
<title>Tu Trueque</title> 
</head>
<body>
<?php 
require_once("includes/funciones.php");
require_once("includes/clase_publicacion.php");
   

?>    


  <a href='index.php'>
	<div id='cabecera_logo'>
		<div id='logo'>
		</div> 
        <?php datosUsuario();?>
	</div>
  </a>
	

  <div id ='botones_cabecera' class ='botones_cabecera' >
        <div class = 'div_boton' >
           <a class='enlaceboton' href='frmPublicar.php'>Publicar</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./miCuenta.php'>Mi Cuenta</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./frmRegistrarUsuarios.php'>Registrarse</a>
        </div>
        <div class = 'div_boton' >
           <a class='enlaceboton' href='./login.php'>Ingresar</a>
        </div>
  </div><!--botones_cabecera-->

<div id="contenedor">
     <div id="main">
         <div id="columna1">
            <div id="borde_externo" class="redondear">
            <div id="borde_interno" class="redondear">
               <ul id="menu" class="redondear">
			   
			   <?php
			      $result = publicacion::listar_categorias();
 				   if ($result) 
                  
				     while ($categoria = mysqli_fetch_array($result, MYSQLI_ASSOC) )
					   {
					      echo "<li><a href='#'>".$categoria['nombre']."</a>";
					      echo "<ul>";
                            
						  $result2 = publicacion::listar_subcategorias($categoria['id_categoria']);
						  
						  while ($subcategoria = mysqli_fetch_array($result2, MYSQLI_ASSOC) )
						    {
							   echo "<li><a href='buscarPublicacionCategoria.php?id_subcategoria=".$subcategoria['id_subcategoria']."&page=1&cbEstado=-1'>".$subcategoria['nombre']."</a></li>";
							   
							}
					    echo "</ul>";	 
					     echo "</il>";	 
					  }
			   ?>
               </ul><!--menu-->
            </div> <!--borde interno-->                 
            </div> <!--borde externo-->          
         </div><!--columna1-->
         <div id="columna2">
            <div id="contenedor_busqueda" >  
                 <form id = "frmBuscar" name = "frmBuscar" action = "publicacionBuscar.php" method="post">
                      <div style="width:90%; height:100%; margin: 0 auto;" >
                         <div id="campo_busqueda" class="redondear" >
                            <input class="txt_campo_buscar" type="text" name="txtBuscar" id="txtBuscar" />
                         </div><!--campo busqueda-->
                         <div id="contenedor_boton_busqueda" >
                            <input class="boton_normal" type="button" name="cmdBuscar" id="cmdBuscar" value="Buscar" style="height:40px" onclick="buscar()" />
                         </div>
                      </div>
                      <input type="hidden" id="page" name="page" value="1">
					  <input type="hidden" id="cbEstado" name="cbEstado" value="-1">
                 </form>     
                </div><!--contenedor_busqueda-->
            
            <div id="contenedor_galeria" > 
                <div id="galeria">
                     <ul style="background:#FFF">
                        <?php 
								  $result = publicacion::publicacionUltimas();
								  if ($result )
								     while($publicacion = mysqli_fetch_array($result, MYSQL_ASSOC)) 
									  {
										   $id_foto = $publicacion['id_fotos'];
										 echo "<li><a title='' href='publicacion.php?id_publicacion=".$publicacion['id_publicacion']."'><img id='foto' src='cargarImagenPublicacion.php?id_foto=".$publicacion['id_fotos']."'/><span>".$publicacion['titulo']."</span></a></li>";
									  }
								?>
                        
                        <!--li><a title=""href="URL-ENLACE"><img alt="foto" src="URL-IMAGEN"/><span>T�tulo</span></a></li-->
                     </ul>
                  </div><!--galeria-->
            </div><!--contenedor galeria-->
         </div><!--columna2-->
      
</div><!--main-->

<!--div id="desarrollado">Desarrollado por Carlos Parra</div>     
</div><!--contenedor-->
<script type="text/javascript">
function buscar(){
   if (document.frmBuscar.txtBuscar.value.length == 0)
   {
	  alert('Debe ingresar un texto en la busqueda');  
      return false; 
   }
   document.frmBuscar.submit();	  
}
</script>
</body>
</html>
