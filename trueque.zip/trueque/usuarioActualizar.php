<?php
  require_once("includes/clase_usuario.php");
  require_once("includes/funciones.php");
  $mensaje = usuario::usuarioActualizar($_POST['id_usuario'],
                             $_POST['txtNombre'],
							 $_POST['txtCorreo'], 
							 $_POST['txtTelefono'],
							 $_POST['txtDireccion'],
							 formatoFecha($_POST['txtFecha']),
							 $_POST['cbEstado']);
							 
  echo trim($mensaje);							 
  			

    //enviarCorreo($_POST['txtCorreo'], CORREO_USUARIO, CORREO_NOMBRE, 'Bienvenido a Tus Trueques', $body);                                          
                                         

?>
