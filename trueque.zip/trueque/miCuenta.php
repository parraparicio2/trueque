<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript">
   //gradiente('botones_cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
	//gradiente('separador_menu_usuario1', '8080FF', '4D51F2', 'vertical', '', '' );
	//gradiente('separador_menu_usuario2', '8080FF', '4D51F2', 'horizontal', '', '' );
	//gradiente('separador_menu_usuario3', '8080FF', '4D51F2', 'horizontal', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
</script>
<title>Datos Personales</title>
</head>

<body>
<?php
require_once("includes/funciones.php");
//include("configuracion/configurar.php");
require_once("includes/clase_publicacion.php");
   escribirCabecera();

?>  
<div id="contenedor">
	<div id="main">
		<div id="columna_usuarios">
			 <div id="borde_menu_usuario" class ="borde_inferior" >
				<div id="borde_menu_usuario_i" class ="borde_inferior" >
					   <div id="separador_menu_usuario1" class = "separador_menu_usuario">
						   Usuario
					   </div> <!--separador_menu_usuario-->
					   <div id="opcion_menu_usuario">
						  <li><a class="enlace_menu_usuario" href="frmUsuarioActualizar.php" target="fraPagina">Actualizar datos</a>
						  <li><a class="enlace_menu_usuario" href="frmSeguridad.php" target="fraPagina">Seguridad</a>
						  <li><a class="enlace_menu_usuario" href="frmUsuarioBaja.php" target="fraPagina">darse de baja</a>
					   </div> <!--opcion_menu_usuario-->
					   
					   <div id="separador_menu_usuario2" class ="separador_menu_usuario">
						   Mis publicaciones
					   </div> <!--separador_menu_usuario-->
					   <div id="opcion_menu_usuario">
						  <li><a class="enlace_menu_usuario" href="publicacionBuscarActivas.php?page=1" target="_top">Activas</a>
						  <li><a class="enlace_menu_usuario" href="publicacionBuscarInactivas.php?page=1" target="_top">Finalizadas</a>
                    <li><a class="enlace_menu_usuario" href="publicacionPreguntas.php" target="_top">Preguntas por responder</a>
					   </div> <!--opcion_menu_usuario-->
		   
					   <div id="separador_menu_usuario3" class ="separador_menu_usuario">
						   Ofertas
					   </div> <!--separador_menu_usuario-->
					   <div id="opcion_menu_usuario" class ="redondear_opcion">
						  <li><a class="enlace_menu_usuario" href="ofertaBuscarActivas.php" target="_top">Mis Ofertas</a>
						  <li><a class="enlace_menu_usuario" href="ofertaBuscarOfertas.php" target="_top">Ofertas a mis publicaciones</a>
					   </div> <!--opcion_menu_usuario-->


				</div><!--borde_menu_usuario_i-->
			 </div><!--borde_menu_usuario-->
		</div><!--columna_usuarios-->
		  <div id="columna_datos" >
        <?php 
		       
		       if (trim($_SESSION['pagina_usuario']) == '')
		        {
				   $_SESSION['pagina_usuario'] = 'frmCuenta.php';
				};
		  
		   ?>
        <iframe name = "fraPagina" id = "fraPagina"  src="<?php echo $_SESSION['pagina_usuario'] ?>"  class = "marcos" scrolling="no" frameborder="0" />
		  </div><!--columna_datos-->
	</div><!--main-->
</div><!--contenedor-->
</body>
</html>
