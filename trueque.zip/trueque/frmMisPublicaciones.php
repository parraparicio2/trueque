<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/resaltar.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript">
   gradiente('cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario1', '8080FF', '4D51F2', 'vertical', '', '' );
	gradiente('separador_menu_usuario2', '8080FF', '4D51F2', 'horizontal', '', '' );
	gradiente('separador_menu_usuario3', '8080FF', '4D51F2', 'horizontal', '', '' );
   redondearBordes(this);//funcion para redondear bordes de los div con la clase llamada redondear 
</script>
<title>Datos Personales</title>
</head>

<body>
<?php
session_start();
?>
<div id="datos_usuario">
<?php 
  if (isset( $_SESSION['id_usuario']))
     echo $_SESSION['logout'];
?>    
</div>

<div id="cabecera" class = "cabecera">
   <div id="cabecera_logo">
     <div id ="logo">
     </div><!--logo-->
   </div>
<div id ="botones_cabecera" class ="botones_cabecera" >
        <div class = "div_boton" style=" border-right:0px" >
           <a class="enlaceboton" href="">Ayuda</a>
        </div>
        <div class = "div_boton" >
           <a class="enlaceboton" href="">Publicar</a>
        </div>
        <div class = "div_boton" >
           <a class="enlaceboton" href="">Ingresar</a>
        </div>
        <div class = "div_boton" >
           <a class="enlaceboton" href="./login.html">Inicio</a>
        </div>
     <!--/div-->
  </div><!--botones_cabecera-->
</div><!--cabecera-->

<div id="contenedor">
	<div id="main">
		<div id="columna_usuarios">
			 <div id="borde_menu_usuario" class ="borde_inferior" >
				<div id="borde_menu_usuario_i" class ="borde_inferior" >
					   <div id="separador_menu_usuario1" class = "separador_menu_usuario borde_superior">
						   Usuario
					   </div> <!--separador_menu_usuario-->
					   <div id="opcion_menu_usuario">
						  <li><a class="enlace_menu_usuario" href="frmUsuarioActualizar.php">Actualizar datos</a>
						  <li><a class="enlace_menu_usuario" href="">Seguridad</a>
						  <li><a class="enlace_menu_usuario" href="">darse de baja</a>
					   </div> <!--opcion_menu_usuario-->
					   
					   <div id="separador_menu_usuario2" class ="separador_menu_usuario">
						   Mis publicaciones
					   </div> <!--separador_menu_usuario-->
					   <div id="opcion_menu_usuario">
						  <li><a class="enlace_menu_usuario" href="">Activas</a>
						  <li><a class="enlace_menu_usuario" href="">Finalizadas</a>
					   </div> <!--opcion_menu_usuario-->
		   
					   <div id="separador_menu_usuario3" class ="separador_menu_usuario redondear">
						   Ofertas
					   </div> <!--separador_menu_usuario-->
					   <div id="opcion_menu_usuario" class ="redondear_opcion">
						  <li><a class="enlace_menu_usuario" href="">Mis Ofertas</a>
						  <li><a class="enlace_menu_usuario" href="">Ofertas a mis publicaciones</a>
					   </div> <!--opcion_menu_usuario-->
				</div><!--borde_menu_usuario_i-->
			 </div><!--borde_menu_usuario-->
		</div><!--columna_usuarios-->
		  <div id="columna_datos">
           <div id="contenedor_formulario" style="padding-top:25px;">
              <div id="div_formulario" class="formulario">
                <form id="frmUsuarios" name="frmUsuarios" method="post" action="">
                         <div id="header_formulario">    
                         </div><!--cabecera-->
                         
                         <div class="tabla">
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Nombre</div>
                               <div class="columna_derecha"><input name="txtNombre" type="text" class ="campo campo_largo" id="txtNombre" lang= "el nombre " maxlength="60"/></div>
                            </div> <!--fila-->   
               
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Correo ElÃ©ctronico</div>
                               <div class="columna_derecha"><input name="txtCorreo" type="text" class ="campo campo_mediano" id="txtCorreo" maxlength="30" /> </div>
                            </div> <!--fila-->   
               
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Fecha de Nacimiento</div>
                               <div class="columna_derecha">
                                 <input name="txtFecha" type="text" class ="campo campo_fecha" id="txtFecha" value="" maxlength="10" />
                                  <img src="images/calendar.gif" alt="" width="16" height="16"  id = "img_calendario"/> DD/MM/AAAA
                               </div><!--columna_derecha-->
                            </div> <!--fila-->   
                            
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">TelÃ©fono</div>
                               <div class="columna_derecha"><input name="txtTelefono" type="text" class ="campo campo_largo" id="txtTelefono" maxlength="50" /></div>
                            </div> <!--fila-->   
                            
                         <div class="fila" style="height:110px" >
                               <div class="columna_izquierda" style="height:80px">DirecciÃ³n</div>
                               <div class="columna_derecha">
                                  <textarea class="campo" name="txtDireccion" id="txtDireccion" cols="35" rows="5"></textarea>
                               </div>
                            </div> <!--fila-->   
               
                            <div class="fila" style="height:50px">
                               <div class="columna_izquierda">Estado</div>
                               <div class="columna_derecha">
                                  <select class = "campo" style=" width:150px " name="cbEstado" id="cbEstado" >
                                     <option value="1">1</option>
                                  </select>
                               </div>
                            </div> <!--fila-->      
               
                         </div> <!--tabla-->
                        <div class ="botones_formulario"> 
                           <input class = "boton_comando" id ="cmdGuardar" name="cmdGuardar" type="button" value="Guardar" onclick="validarPagina()"/>
                        </div>
                  </form>
                  </div><!--div_formulario-->   
                  
           </div><!--contenedor_formulario-->
		  </div><!--columna_datos-->
	</div><!--main-->
</div><!--contenedor-->
</body>
</html>
