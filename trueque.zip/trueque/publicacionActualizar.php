﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>
<?php 
require_once("includes/clase_publicacion.php");
//require_once("includes/resize.php");
require_once("includes/funciones.php");
require_once("includes/SimpleImage.php");
session_start();

 $carpeta="tmp/";
 $fecha_publicacion = date("Y-m-d");
  

	if (!empty($_FILES['archivo1']['name']))
	{
	
     $image = new SimpleImage();
     $image->load($_FILES['archivo1']['tmp_name']);
     $image->resizeToWidth(400);
     $image->save($_FILES['archivo1']['tmp_name']);

	  $fileName1 = $_FILES['archivo1']['name'];
	  $tmpName1  = $_FILES['archivo1']['tmp_name'];
	  
	  $fileType1 = $_FILES['archivo1']['type'];
	  $fileSize1 = $_FILES['archivo1']['size'];

	  $foto1 = transformarImagen($fileName1, $tmpName1, $fileSize1);
	  //unlink($carpeta.basename($fileName1));

	}
	if (!empty($_FILES['archivo2']['name']))
	{
     $image = new SimpleImage();
     $image->load($_FILES['archivo2']['tmp_name']);
     $image->resizeToWidth(400);
     $image->save($_FILES['archivo2']['tmp_name']);

	  $fileName2 = $_FILES['archivo2']['name'];
	  $tmpName2  = $_FILES['archivo2']['tmp_name'];
	  $fileSize2 = $_FILES['archivo2']['size'];
	  $fileType2 = $_FILES['archivo2']['type'];
	  $foto2 = transformarImagen($fileName2, $tmpName2, $fileSize2);
	  
	//  unlink($carpeta.basename($fileName2));
	}	
	if (!empty($_FILES['archivo3']['name']))
	{

     $image = new SimpleImage();
     $image->load($_FILES['archivo3']['tmp_name']);
     $image->resizeToWidth(400);
     $image->save($_FILES['archivo3']['tmp_name']);

	  $fileName3 = $_FILES['archivo3']['name'];
	  $tmpName3  = $_FILES['archivo3']['tmp_name'];
	  $fileSize3 = $_FILES['archivo3']['size'];
	  $fileType3 = $_FILES['archivo3']['type'];
	  $foto3 = transformarImagen($fileName3, $tmpName3, $fileSize3);
	  //unlink($carpeta.basename($fileName3));
	}	

  if (!isset($fileName1))
  {
	 $fileName1 = NULL;
     $tmpName1  = NULL;
     $fileSize1 = NULL;
     $fileType1 = NULL;
	 $foto1     = NULL;
  }
  if (!isset($fileName2))
  {
	 $fileName2 = NULL;
     $tmpName2  = NULL;
     $fileSize2 = NULL;
     $fileType2 = NULL;
	 $foto2     = NULL;	  
  }
  if (!isset($fileName3))
  {
	 $fileName3 = NULL;
     $tmpName3  = NULL;
     $fileSize3 = NULL;
     $fileType3 = NULL;
	 $foto3     = NULL;	  
  }

		  
 $publicacion = publicacion::publicacionActualizar($_POST['id_publicacion'],
                                                   $_POST['id_subcategoria'], 
                                                   $_POST['id_usuario'], 
      											   $_POST['txtTitulo'], 
  												   $fecha_publicacion,
  												   $_POST['cboDias'], 
  												   $_POST['txtDescripcion'],
  												   $_POST['optCondicion'],
  												   $foto1,
  												   $fileType1,
  												   $fileSize1,																	
  												   $foto2,
  												   $fileType2,
  												   $fileSize2,																	
  												   $foto3,
  												   $fileType3,
  												   $fileSize3,
  												   $_POST['id_foto_1'],
  												   $_POST['id_foto_2'],
  												   $_POST['id_foto_3']																	
																   );

echo "<script>alert('".$publicacion."')</script>";	
//header('Location: index.php');
//header('Location:index.php');

   if (!empty($_FILES['archivo1']['name']))
	   unlink($carpeta.basename($fileName1));
   if (!empty($_FILES['archivo2']['name']))
	   unlink($carpeta.basename($fileName2));
   if (!empty($_FILES['archivo3']['name']))
	   unlink($carpeta.basename($fileName3)); 
																
												 
?>

<body>
<script>window.location = 'publicacion.php?id_publicacion=<?php echo $_POST['id_publicacion'] ?>';

</script>
</body>
</html>