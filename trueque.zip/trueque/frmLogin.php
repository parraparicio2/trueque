<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
<LINK rel="stylesheet" href="./css/form.css" type="text/css"/>
<LINK rel="stylesheet" href="./css/estilos.css" type="text/css"/>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/jquery-ui.min.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript">
   gradiente('botones_cabecera', '8080FF', '4D51F2', 'horizontal', '', '' );
$( "#dialog-form" ).dialog({
			autoOpen: false,
			height: 300,
			width: 350,
			modal: true
		});
</script>


</head>
<body>

<?php
  include('includes/clase_usuario.php'); 
  

  $txtLogin = "";
  $txtPassword="";
   
  if (isset($_POST['txtLogin']))
    {
	  $usuario = usuario::usuarioSesion($_POST['txtLogin'], $_POST['txtPassword']);
	  if ($usuario)
	    {
 		   session_start();
		   $_SESSION['id_usuario']  = $usuario['id_usuario'];
         $_SESSION['login'] = trim($usuario['login']);
			$_SESSION['pagina_usuario']  = "";
		   $_SESSION['logout'] = "<a class='hipervinculo' href='logout.php'>".$_SESSION['login']." (Salir)</a>";
   		echo "<script>$(function() { $( '#login' ).dialog( 'destroy' )	});</script>";	
       }  
	  else
	     {
	     echo "<script>alert('Login o Contraseña invalida!');</script>";	
		  }
	} 
?>

         <div id ="div_borde" style="border: 1px #CCC solid; height:250px; padding:20px; float:left; margin-top:2px; background:#CCC" > 
            <div id = "div_titulo" class = "titulo" style="padding-left:2px; text-align:justify"> Ingresar a Tu Trueque </div>
            <div style="padding:10px"> </div>
    <!--------------------------------------------------------------------------------------------------->           
            <div id ="div_login" class = "columna_izquierda" style="width:50%; height:150px; ">
               <form class = "formulario_corto" id="frmLogin" name="frmLogin" method="post" action="login.php" style="padding:0px;">
                     <div id="" class="fila" style="height:100%">
                        <div class="columna_izquierda_p">Login</div>
                        <div class="columna_derecha_p" style="width:150px">
                           <input name="txtLogin" class ="campo_corto" id="txtLogin"  maxlength="16" lang="el login"   />
                        </div>
                     </div><!--fila-->
                     
                     <div id="" class="fila">
                        <div class="columna_izquierda_p">Contrase&ntilde;a</div>
                        <div class="columna_derecha_p" style="width:150px">
                           <input class ="campo_corto"  type="password" name="txtPassword" id="txtPassword" maxlength="16" lang ="la contraseña"/>
                        </div>
                     </div><!--fila--> 
                  
                  <div class ="botones_formulario">
                     <input class = "boton_comando" id ="cmdAceptar" name="cmdAceptar" type="button" value="Aceptar" onclick="validarLogin()"/>
                     <input class = "boton_comando" id ="cmdCancelar" name="cmdCancelar" type="button" value="Cancelar" onclick= "$(function() { $( '#login' ).dialog( 'close' )	})" />
                  </div>
               </form>
            </div><!--columna izquierda-->
         </div><!--div_borde-->
         

