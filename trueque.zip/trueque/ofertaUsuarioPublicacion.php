<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="STYLESHEET" type="text/css" href="./css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/menu_categorias.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/formwizard.css"/>
<link rel="STYLESHEET" type="text/css" href="./css/form.css"/>
<link rel="STYLESHEET"  href="./css/jquery-ui.css" >
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./js/jquery.corners.js"></script>
<script type="text/javascript" src="./js/menu_categorias.js"></script>
<script type="text/javascript" src="./js/jquery.gradient.js"></script>
<script type="text/javascript" src="./js/css.js"></script>
<script type="text/javascript" src="./js/jquery-ui.min.js"></script>
<script type="text/javascript" src="./js/funciones_trueque.js"></script>
<script type="text/javascript" >
   gradiente('botones_cabecera', '8080FF', '4D51F2', 'vertical', '', '' );

</script>

<title>Tu Trueque</title> 
</head>
<body>


<?php
require_once("includes/clase_oferta.php");
require_once("includes/funciones.php");
   escribirCabecera();
  // iniciarSesion();
?>   
<div id="contenedor">
   <div id="main">
   <p class="p_informacion">Seleccione las publicaciones que desea ofertar</p>
<?php 
$result = oferta::ofertaPublicacionUsuario($_SESSION['id_usuario'], $_POST['id_publicacion']);

if ($result)
   $numero_filas = mysqli_num_rows($result);
else
   $numero_filas = 0;
      
  if ($numero_filas == 0)
    {
	?>	
			   <div id="contenedor_formulario"  style="padding-top:20px">
				  <div id="div_formulario" class="formulario" style="padding-bottom:10px">
					<form id="frmOferta" name="frmOferta" method="post" action="frmPublicar.php">
							 <div id="header_formulario">    
							 </div><!--cabecera-->
							 
							 <div class="tabla">
								
								<div class="fila" style="height:50px; padding:20px;">
								   <p class ="informacion"> No tienes publicaciones para ofertar.</p>
                                   <p class ="informacion"> Debes realizar una publicaci&oacute;n</p>
								 </div> <!--fila-->   
								   
                       
								<div class ="botones_formulario"> 
								   <input class = "boton_comando" id ="cmdPublicar" name="cmdPublicar" type="submit" value="Publicar" />
								</div>
							 </div> <!--tabla-->
                            
					  </form>
					  </div><!--div_formulario-->   
			   </div><!--contenedor_formulario-->
     <?php 	
		exit;
    }
  else
     {	
	 echo "<form id='frmOferta' name='frmOferta' method='post' action='ofertaRegistrar.php'>";
      echo "<div id='datos_publicacion_busqueda' class='tablacss'>
					<div id='titulo' class = 'filascss' >
						<div id='col_titulo1' class = 'col_titulocss col_foto col_titulo_publicacion col_bordes' >Foto</div>
						<div id='col_titulo2' class = 'col_titulocss col_publicacion_oferta col_titulo_publicacion col_bordes' >Publicaci&oacute;n</div>
						<div id='col_titulo5' class = 'col_titulocss col_oferta col_titulo_publicacion col_bordes' >Ofertar</div>
 		            </div>";	


$i = 0;
while ($publicacion = mysqli_fetch_array($result, MYSQLI_ASSOC)) 
  {
	 if ($publicacion['id_fotos'] == NULL)
	   $id_foto = -1;
	 else
	    $id_foto = $publicacion['id_fotos'];
		 	
	       echo "
	         <div id='fila1' class = 'filascss' >
		         <div id='columna_foto' class = 'colcss col_foto col_propiedades_publicacion col_bordes' >";
					     echo "<a href='publicacion.php?id_publicacion=".$publicacion['id_publicacion']."' TARGET='_parent' ><img src='cargarImagenPublicacion.php?id_foto=".$id_foto."' class ='col_imagen'/></a>";
			echo "</div><!--columna_foto-->
			
				<div id='columna_publicacion' class = 'colcss col_publicacion_oferta col_propiedades_publicacion col_bordes' ><a class = 'hipervinculo' href='publicacion.php?id_publicacion=".$publicacion['id_publicacion']."' TARGET='_parent' >".$publicacion['titulo']."</a><img class='valign'></div><!--columna_publicacion-->
				<div id='columna_oferta' class = 'colcss col_oferta col_propiedades_publicacion col_bordes' ><input type='checkbox' id = 'chPublicacion' name = 'chPublicacion[".$i."]'  value = '".$publicacion['id_publicacion']."' ><img class='valign'></div><!--columna_publicacion-->
				</div><!--fila1-->
				";
$i++;
}


		echo"	<div id='fila3' class = 'filascss' >
				   <input type ='button' name = 'cmdOfertar' id = 'cmdOfertar' value ='Ofertar' class = 'boton_comando' onclick='ofertar()'>
				   <input type ='button' name = 'cmdCancelar' id = 'cmdCancelar' value ='Cancelar' class = 'boton_comando' onClick='cancelar()'>
				</div>";

echo "</div>";//datos publicacion




}

?>
<input id="id_publicacion" name = "id_publicacion" type = "hidden" value = "<?php echo $_POST['id_publicacion'] ?>"  >
<input id="id_usuario" name = "id_usuario" type = "hidden" value = "<?php echo $_SESSION['id_usuario'] ?>"  >

   </form>
   </div><!--main--> 
</div><!--contenedor-->
<script type="text/javascript" >
function cancelar()
{
	//document.frmOferta.action = 'index.php';
	//document.frmOferta.submit();
	window.top.location = 'index.php';
	
}
function ofertar()
{
	var publicacion = document.getElementById('chPublicacion'); 
	var activo = false;
	 
     //esta condicion esta cuando es una sola publicacion y no se crea el array     
     if (!document.frmOferta.chPublicacion.length)
	    {
			if (document.frmOferta.chPublicacion.checked)
			   activo = true; 
		} 
	//aqui es cuando se crea el array cuando es mas de una publicacion	
	 for(i=0; i <= document.frmOferta.chPublicacion.length-1; i++)
	   {
	     if(document.frmOferta.chPublicacion[i].checked)
		    activo = true; 
	   }
	 
     if (!activo)
      {
		 alert('Debe seleccionar al menos una (1) publicación ');
		 return false;
	  }
   
   document.frmOferta.action = 'ofertaRegistrar.php';
   document.frmOferta.submit();
}   

</script>


</body>
</html>

